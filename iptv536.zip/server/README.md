# Serveur de Sous-Titrage Vocal Temps Réel (Sherpa-ONNX + FFmpeg)

Système de transcription vocal en streaming **100% hors-ligne (offline)**, sans clé API cloud, optimisé pour flux HLS Live (`.m3u8`) et fichiers VOD (MP4/MKV).

---

## 1. Installation sur Ubuntu Server 22.04 / 24.04

```bash
# 1. Mise à jour et paquets système nécessaires
sudo apt update && sudo apt install -y python3 python3-pip ffmpeg wget bzip2

# 2. Cloner ou copier le dossier 'server' sur votre serveur
cd /opt/sherpa-subtitle-server/server

# 3. Installer les dépendances Python
pip3 install -r requirements.txt

# 4. Télécharger automatiquement les modèles ONNX (Zipformer Live + Whisper VOD + Silero VAD)
bash download_models.sh
```

---

## 2. Lancement du Serveur Live

```bash
python3 server.py
# Le serveur démarre sur le port 8000 : ws://0.0.0.0:8000/ws/subtitles/{channel_id}
```

Pour le faire tourner en service continu avec systemd (`/etc/systemd/system/sherpa-subtitles.service`) :
```ini
[Unit]
Description=Sherpa-ONNX Live Subtitle Server
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/opt/sherpa-subtitle-server/server
ExecStart=/usr/bin/python3 server.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

---

## 3. Transcription VOD (Génération de fichier .srt)

Pour transcrire un film ou un épisode complet en générant un `.srt` horodaté :
```bash
python3 vod_transcriber.py /chemin/vers/film.mp4
# Génère automatiquement /chemin/vers/film.srt
```
