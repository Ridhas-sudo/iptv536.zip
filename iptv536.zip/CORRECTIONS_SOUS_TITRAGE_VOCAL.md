# Corrections – sous-titrage vocal (Google TV)

## Bugs bloquants corrigés
1. **Sous-titres partiels jamais affichés** (`SherpaSubtitleManager`) : `lastPartialText` était écrasé avant le test
   « nouveau texte ? ». Résultat : rien ne s'affichait avant la fin de phrase (pause de 0,5–0,9 s). Le mode
   streaming fonctionne maintenant réellement.
2. **Repliement de spectre (aliasing)** : la décimation 48 kHz → 16 kHz prenait 1 échantillon sur 3 sans filtre.
   Nouveau pipeline : downmix → passe-bas 7 kHz (2 biquads) → interpolation linéaire avec état conservé entre buffers.
   Meilleure précision de reconnaissance.
3. **Audio perdu quand l'UI TV est chargée** : le worker attendait le thread principal (`withContext(Main)`).
   Les callbacks sont maintenant postés sans bloquer le décodage.
4. **Réglage de synchro sans effet en streaming** : les partiels contournaient le délai, et le délai annulait
   chaque résultat précédent. Remplacé par une vraie ligne à retard numérotée (les résultats périmés après
   seek/zapping sont ignorés). Le ViewModel consomme désormais un seul canal.
5. **Release/R8** : ajout de la règle ProGuard `-keep class com.k2fsa.sherpa.onnx.**` (sinon crash JNI en release).
6. **Langues** : `ru` utilisait le modèle français ; elle utilise maintenant le modèle multilingue. Pour les langues
   sans modèle streaming dédié (es, de, it, pt, tr) un avertissement est affiché au lieu d'un silence trompeur.
   Le même modèle n'est plus rechargé sous deux codes différents.

## Améliorations de confort
- Texte anglais du modèle (MAJUSCULES) converti en casse normale, majuscule initiale, « I » corrigé.
- Fenêtre glissante : jamais plus de ~2 lignes (96 car.) en partiel, 160 en final.
- Durée d'affichage : 1,5 s + 60 ms/caractère (2,5–8 s) au lieu de 4,5–18 s.
- Gain automatique lissé (plus de pompage entre chunks) ; indicateur « parole détectée » qui retombe au silence.
- 2 threads d'inférence sur les boîtiers ≥ 4 cœurs (1 thread ne tenait pas le temps réel sur A53/A55).
- Chargement des libs natives séparé (une lib absente n'empêche plus le chargement des autres).
- Calibrage auto sans délai artificiel de base (offset initial 0 ms au lieu de 120 ms).
- Regex de nettoyage : ne supprime plus un mot parlé comme « Source » ou « Traduction » en début de phrase.

## Non testé / à savoir
- Le code n'a pas pu être compilé ici (pas de SDK Android) : faire un build Android Studio et tester sur la TV.
- `LiveSubtitleWebSocketManager` et `server/` ne sont utilisés par aucun écran de l'app (code inutilisé).
- Le lecteur Multiview n'a pas de sous-titrage vocal (pas d'AudioProcessor).
- Pour es/de/it/pt/tr il faudrait ajouter de vrais modèles streaming dans `AVAILABLE_MODELS`.

---
# Lot 2 – Arabe en carrés + plantage (TCL Google TV)

## Arabe affiché en carrés « ▯ »
Cause : la police système de nombreuses TCL Google TV n'a pas les glyphes arabes.
Correctif : police **DejaVu Sans** (latin + cyrillique + arabe avec formes de liaison, ~300 Ko) embarquée dans
`res/font/` et utilisée par les 2 overlays Compose (`SubtitleFontFamily`) ET par le SubtitleView natif
d'ExoPlayer (`SubtitleFonts.bold`). Licence : `licenses/DejaVu-fonts-LICENSE.txt`.

## Plantage
- Cause la plus probable (modèle arabe = 340 Mo sur une TV à ~2 Go de RAM) : manque de mémoire → l'OS tue l'app
  sans exception Java. Correctifs :
  - vérification de la RAM libre avant chargement (message clair au lieu d'un plantage) ;
  - l'ancien modèle est libéré AVANT de charger le nouveau (avant : FR + AR en mémoire en même temps) ;
  - 1 seul thread d'inférence pour l'arabe (moins de RAM) ;
  - **garde-fou anti boucle de plantage** : si un chargement de modèle tue l'app, le modèle est bloqué au
    redémarrage suivant au lieu de replanter à chaque lancement (supprimer le modèle le débloque).
- Rapport de plantage : les exceptions Java sont écrites dans `crash_last.txt`
  (Android/data/com.aistudio.proiptv.kxypt/files/) et affichées au lancement suivant.

---
# Lot 3 – Sous-titres vocaux arabes absents + Réglages

## Sous-titres vocaux traduits (arabe) qui ne s'affichaient pas
- **Cause 1 (régression du lot 1)** : chaque nouveau partiel annulait la traduction en cours. Une traduction réseau
  prenant 200-600 ms, elle était annulée avant la fin -> l'arabe n'arrivait jamais. Nouveau pipeline : la traduction
  en cours n'est plus annulée, seul le DERNIER texte est mis en attente puis traduit (`runVoiceTranslationLoop`).
- **Cause 2** : ML Kit `downloadModelIfNeeded().await()` sans délai maximum pouvait bloquer indéfiniment (TV sans
  téléchargement possible) et le repli HTTP n'était jamais atteint. Maintenant : ML Kit seulement si les deux modèles
  sont déjà présents (test limité à 0,8 s, traduction limitée à 2,5 s), sinon traduction HTTP immédiate et
  téléchargement des modèles en arrière-plan pour un usage hors-ligne ultérieur.

## Réglages
- Suppression complète du bloc jaune/orange « Optimisation Flux & Playlists Volumineux » / « TURBO ON ».
  Les optimisations (démarrage rapide, GZIP, HLS chunkless, multi-flux) restent ACTIVES par défaut en arrière-plan.
- Nouvelle carte « Partage des Données de Playlists » (`ui/PlaylistSharing.kt`) :
  - **Partager Toutes** : récapitulatif structuré + feuille de partage Android ;
  - **Copier Tout** : copie dans le presse-papiers ;
  - **Détails / Par Playlist** : liste avec badge M3U / XTREAM / STALKER, boutons **Copier** et **Partager** par playlist.
  - Contenu : nom, type, URL, identifiants + mot de passe Xtream, adresse MAC (et IP) Stalker.
  - Si la TV n'a aucune application de partage, le texte est copié automatiquement à la place.

---
# Lot 3b – Correctif de compilation
- `IptvViewModel.kt` : erreur « Type mismatch: inferred type is String? but String was expected » (ligne ~487,
  `refreshAutoClearTimer(translated)`). La variable `translated` est maintenant un `val translated: String`
  explicitement non nul (`cache ?: run { ... }`).
- Vérification : aucun import en conflit (FontFamily / LayoutDirection) ni nom de fonction en double dans le projet.

---
# Lot 4 – Correctifs de compilation (build GitHub Actions)
- `IptvViewModel.kt` ligne ~487 : « Type mismatch: String? but String was expected ».
  `translated` est maintenant un `val translated: String` explicite (`cache ?: run { ... }`), plus de variable nullable.
- `MainActivity.kt` : `catch (_: Throwable)` remplacé par `catch (ignored: Throwable)` (le `_` n'est pas accepté en Kotlin 1.9).
- Relecture complète des diffs (Sherpa, ViewModel, TranslationManager, MainActivity, IptvAppScreen, PlaylistSharing,
  SubtitleFonts) : imports, types nullables, signatures et portées vérifiés. Aucune compilation réelle possible ici.

---
# Lot 5 – Diagnostic TV (sous-titres vocaux absents sur TCL, OK sur smartphone)
Le pipeline fonctionne sur téléphone ; la cause côté TV n'est pas identifiable sans l'appareil. Un bandeau de
diagnostic (haut-gauche de la vidéo, `ui/VoiceDiagnostics.kt`) s'affiche tant que les sous-titres vocaux sont
activés et qu'aucun texte n'est reconnu. Il indique :
- état du modèle : prêt (fr) / NON chargé / téléchargement… (+ message d'erreur, ex. mémoire insuffisante) ;
- format audio reçu du lecteur (Hz, canaux, PCM16/float…) ou « AUCUN audio PCM reçu » / « format NON PCM » ;
- nombre de blocs audio reçus et décodés, niveau sonore.
Il disparaît dès qu'un sous-titre s'affiche.

---
# Lot 6 – Google TV : modèle vocal « NON chargé » alors que « prêt ! » s'affiche
Constat (captures TV) : audio bien reçu et décodé (48 kHz, 2 ch, PCM16, niveau > 0) mais modèle « NON chargé »,
le message « Modèle … prêt ! » n'étant que le reliquat du téléchargement.

Causes corrigées (`SherpaSubtitleManager`) :
- À l'activation, `setSourceLanguage` était appelé 2-3 fois d'affilée ; chaque appel annulait le job précédent, mais le
  chargement natif ne s'interrompt pas -> plusieurs chargements de 130-340 Mo en parallèle (saturation RAM d'une TV,
  modèles qui s'écrasent entre eux). Nouveau chargeur **à file unique** (`loadMutex`) : le dernier modèle demandé gagne,
  jamais deux chargements simultanés, plus d'annulation.
- Le statut « prêt ! » n'était jamais remplacé : il devient « Modèle vocal chargé ✓ » après un vrai chargement.
- **Watchdog** (toutes les 4 s) : si la reconnaissance est active et qu'aucun modèle n'est chargé ni en cours de
  chargement, le chargement est relancé (3 essais max).
- Contrôle mémoire : n'est plus bloquant tant que la RAM libre ≥ 50 % du besoin estimé (avertissement seulement).
- Le bandeau de diagnostic indique maintenant : « chargement en cours (N s) », « ÉCHEC (cause exacte) »,
  ou l'erreur de chargement des bibliothèques natives (ex. ABI incompatible).

---
# Lot 7 – Google TV : français approximatif/décalé, arabe écrit en lettres latines
Constat (captures) : modèle chargé OK, mais « reçu 3440 | décodé 1582 » -> la TV ne décodait que ~46 % de l'audio
en temps réel ; le reste était jeté (mots absurdes, retard). Sur la chaîne arabe, du texte latin s'affichait.

## Retard / mots absurdes
- Thread de calcul en priorité élevée (le décodage vidéo/UI le privait de CPU).
- Threads d'inférence : 3 (>= 4 cœurs) ou 4 (>= 6 cœurs) au lieu de 2 (1 pour l'arabe).
- File audio réduite (30 blocs ~ 3 s max de retard au lieu de 6,4 s).
- Quand des blocs sont perdus, le flux de reconnaissance est remis à zéro (au lieu de décoder un audio troué).
- Le bandeau affiche « perdu N » et « Vitesse calcul : x.xx fois le temps réel » (>= 0,9 = TV trop lente).

## Arabe en lettres latines
- Le modèle FRANÇAIS restait actif quand le modèle arabe (340 Mo) ne pouvait pas se charger (mémoire / téléchargement)
  et transcrivait phonétiquement l'arabe. Désormais : aucun sous-titre n'est produit si le modèle chargé n'est pas celui
  de la langue sélectionnée ; l'ancien modèle est libéré AVANT le test mémoire ; le seuil mémoire est moins strict (40 %).
- Le watchdog compare maintenant au modèle ATTENDU (zapping FR -> AR) et relance le chargement.
- Le bandeau reste affiché en cas de problème (mauvais modèle, échec, TV trop lente) même quand du texte s'affiche.
