package com.example.data

import android.content.Context
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.net.CookieManager
import java.net.CookiePolicy
import java.util.concurrent.TimeUnit

class StalkerPortalClient(
    private val portalUrl: String,
    private val macAddress: String,
    private val context: Context? = null
) {
    
    val cookieManager = CookieManager().apply { 
        setCookiePolicy(CookiePolicy.ACCEPT_ALL) 
    }

    val okHttpClient = OkHttpClient.Builder()
        .cookieJar(JavaNetCookieJar(cookieManager))
        .addInterceptor { chain ->
            val original = chain.request()
            // C'EST ÇA QUI MANQUE CHEZ TOI
            val newRequest = original.newBuilder()
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3")
                .header("X-User-Agent", "Model: MAG200; Link: WiFi")
                .header("Referer", "http://xoxpl8k.me/c/")
                .header("Cookie", "mac=00:1A:79:5A:2F:F9; stb_lang=en; timezone=Europe/Paris;")
                .build()
            chain.proceed(newRequest)
        }
        .addInterceptor(CustomIpInterceptor(context)) // ton intercepteur IP
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val client: OkHttpClient get() = okHttpClient
    
    private var authToken: String = ""
    
    // Étape 1: Handshake
    fun handshake(callback: (Boolean, String?) -> Unit) {
        val url = buildUrl("handshake")
        
        val request = Request.Builder()
            .url(url)
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(false, "Handshake failed: ${e.message}")
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        callback(false, "Handshake HTTP error: ${it.code}")
                        return
                    }
                    
                    val responseBody = it.body?.string()
                    try {
                        val json = JSONObject(cleanStalkerJson(responseBody ?: ""))
                        var token = ""
                        if (json.has("js")) {
                            val jsObj = json.optJSONObject("js")
                            if (jsObj != null) {
                                token = jsObj.optString("token")
                            } else {
                                token = json.optString("js")
                            }
                        }
                        if (token.isEmpty() && json.has("token")) {
                            token = json.optString("token")
                        }
                        if (token.isEmpty() && json.has("result")) {
                            val resObj = json.optJSONObject("result")
                            if (resObj != null) {
                                token = resObj.optString("token")
                            } else {
                                token = json.optString("result")
                            }
                        }
                        
                        authToken = token
                        
                        if (authToken.isNotEmpty()) {
                            callback(true, "Handshake OK - Token: $authToken")
                        } else {
                            callback(false, "Token vide ou non trouvé dans la réponse")
                        }
                    } catch (e: Exception) {
                        callback(false, "JSON parse error: ${e.message}\nResponse: $responseBody")
                    }
                }
            }
        })
    }
    
    // Étape 2: Get Profile
    fun getProfile(callback: (Boolean, String?) -> Unit) {
        val url = buildUrl("get_profile")
        
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $authToken")
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(false, "Get Profile failed: ${e.message}")
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val responseBody = it.body?.string()
                    if (it.isSuccessful && responseBody != null) {
                        try {
                            val json = JSONObject(cleanStalkerJson(responseBody))
                            if (json.has("error")) {
                                callback(false, "Profile Error: ${json.getString("error")}")
                            } else {
                                callback(true, "Profile OK: $responseBody")
                            }
                        } catch (e: Exception) {
                            callback(true, "Profile OK: $responseBody")
                        }
                    } else {
                        callback(false, "Profile HTTP ${it.code}: $responseBody")
                    }
                }
            }
        })
    }
    
    // Étape 3: Get All Channels
    fun getAllChannels(callback: (Boolean, String?, List<Channel>?) -> Unit) {
        val url = buildUrl("get_all_channels", "itv")
        
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $authToken")
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(false, "Get Channels failed: ${e.message}", null)
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val responseBody = it.body?.string()
                    
                    if (!it.isSuccessful) {
                        callback(false, "Channels HTTP ${it.code}: $responseBody", null)
                        return
                    }
                    
                    try {
                        val json = JSONObject(cleanStalkerJson(responseBody ?: ""))
                        val js = json.optJSONArray("js") 
                            ?: json.optJSONObject("js")?.optJSONArray("data")
                            ?: json.optJSONArray("data")
                            ?: json.optJSONObject("result")?.optJSONArray("data")
                        
                        if (js == null) {
                            callback(false, "Format de chaînes inconnu dans la réponse du serveur", null)
                            return
                        }
                        
                        val channels = mutableListOf<Channel>()
                        for (i in 0 until js.length()) {
                            val channelObj = js.optJSONObject(i) ?: continue
                            val channel = Channel(
                                id = channelObj.optString("id", ""),
                                name = channelObj.optString("name", "Unknown").ifEmpty { channelObj.optString("title", "Unknown") },
                                cmd = channelObj.optString("cmd", "").ifEmpty { channelObj.optString("path", "") },
                                logo = channelObj.optString("logo", "").ifEmpty { channelObj.optString("screenshot", "") },
                                number = channelObj.optInt("number", i + 1)
                            )
                            channels.add(channel)
                        }
                        
                        callback(true, "Channels retrieved: ${channels.size}", channels)
                        
                    } catch (e: Exception) {
                        callback(false, "Parse error: ${e.message}\nResponse: $responseBody", null)
                    }
                }
            }
        })
    }
    
    private fun buildUrl(action: String, type: String = "stb"): String {
        var cleanUrl = portalUrl.trim()
        if (!cleanUrl.endsWith("/")) {
            cleanUrl += "/"
        }
        
        // Target server/load.php endpoint
        val targetPath = "server/load.php"
        val finalBaseUrl = if (cleanUrl.contains("/server/load.php")) {
            cleanUrl
        } else {
            "${cleanUrl}$targetPath"
        }
        
        val tokenParam = if (action == "handshake") "" else authToken
        val prehashParam = if (action == "handshake") "&prehash=868b80d5fa1f01394479e0948ba422cb58d87267" else ""
        
        var url = "$finalBaseUrl?type=$type&action=$action&token=$tokenParam$prehashParam&JsHttpRequest=1-xml"
        
        // Append MAC address to request parameter
        val cleanMac = macAddress.trim().uppercase()
        url += "&mac=$cleanMac"
        
        return url
    }
    
    data class Channel(
        val id: String,
        val name: String,
        val cmd: String,
        val logo: String,
        val number: Int
    )
}
