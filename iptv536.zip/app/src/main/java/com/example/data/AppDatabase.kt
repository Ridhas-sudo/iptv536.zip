package com.example.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppDatabase private constructor(context: Context) {

    private val dbHelper = DatabaseHelper(context)

    // DAOs
    private val playlistDaoInstance = PlaylistDao(dbHelper)
    private val channelDaoInstance = ChannelDao(dbHelper)
    private val historyDaoInstance = HistoryDao(dbHelper)
    private val favoriteDaoInstance = FavoriteDao(dbHelper)
    private val recordingDaoInstance = RecordingDao(dbHelper)
    private val watchProgressDaoInstance = WatchProgressDao(dbHelper)
    private val rawCacheDaoInstance = RawCacheDao(dbHelper)
    private val epgCacheDaoInstance = EpgCacheDao(dbHelper)

    fun playlistDao() = playlistDaoInstance
    fun channelDao() = channelDaoInstance
    fun historyDao() = historyDaoInstance
    fun favoriteDao() = favoriteDaoInstance
    fun recordingDao() = recordingDaoInstance
    fun watchProgressDao() = watchProgressDaoInstance
    fun rawCacheDao() = rawCacheDaoInstance
    fun epgCacheDao() = epgCacheDaoInstance

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        @Volatile
        var appContext: Context? = null

        fun getDatabase(context: Context): AppDatabase {
            appContext = context.applicationContext
            return INSTANCE ?: synchronized(this) {
                val instance = AppDatabase(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "iptv_player.db", null, 3) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE playlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    type TEXT,
                    url TEXT,
                    username TEXT,
                    password TEXT,
                    macAddress TEXT,
                    ipAddress TEXT,
                    customIp TEXT,
                    isActive INTEGER DEFAULT 1
                )
            """)
            db.execSQL("""
                CREATE TABLE channels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlistId INTEGER,
                    name TEXT,
                    logoUrl TEXT,
                    streamUrl TEXT,
                    groupName TEXT,
                    type TEXT,
                    hasCatchup INTEGER DEFAULT 0,
                    tvArchiveDuration INTEGER DEFAULT 0,
                    tvArchiveType TEXT,
                    allowLocalTimeshift INTEGER DEFAULT 0,
                    archiveDate TEXT,
                    allowPvr INTEGER DEFAULT 0,
                    stalkerId TEXT
                )
            """)
            db.execSQL("""
                CREATE TABLE history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlistId INTEGER,
                    channelName TEXT,
                    streamUrl TEXT,
                    timestamp INTEGER
                )
            """)
            db.execSQL("""
                CREATE TABLE favorites (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlistId INTEGER,
                    channelName TEXT,
                    streamUrl TEXT
                )
            """)
            db.execSQL("""
                CREATE TABLE recordings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlistId INTEGER,
                    channelName TEXT,
                    streamUrl TEXT,
                    filepath TEXT,
                    programTitle TEXT,
                    scheduledAt INTEGER,
                    durationMinutes INTEGER,
                    isCompleted INTEGER
                )
            """)
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS watch_progress (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlistId INTEGER,
                    contentType TEXT,
                    showId TEXT,
                    seasonNumber INTEGER,
                    episodeNumber INTEGER,
                    episodeId TEXT,
                    title TEXT,
                    posterUrl TEXT,
                    positionMs INTEGER,
                    durationMs INTEGER,
                    lastWatchedAt INTEGER
                )
            """)
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS raw_cache (
                    cacheKey TEXT PRIMARY KEY,
                    playlistId INTEGER,
                    rawData TEXT,
                    updatedAt INTEGER
                )
            """)
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS epg_cache (
                    cacheKey TEXT PRIMARY KEY,
                    epgData TEXT,
                    date TEXT,
                    updatedAt INTEGER
                )
            """)
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS playlists")
            db.execSQL("DROP TABLE IF EXISTS channels")
            db.execSQL("DROP TABLE IF EXISTS history")
            db.execSQL("DROP TABLE IF EXISTS favorites")
            db.execSQL("DROP TABLE IF EXISTS recordings")
            db.execSQL("DROP TABLE IF EXISTS watch_progress")
            db.execSQL("DROP TABLE IF EXISTS raw_cache")
            db.execSQL("DROP TABLE IF EXISTS epg_cache")
            onCreate(db)
        }

        override fun onOpen(db: SQLiteDatabase) {
            super.onOpen(db)
            try {
                db.execSQL("PRAGMA journal_mode = WAL;")
                db.execSQL("PRAGMA synchronous = NORMAL;")
                db.execSQL("PRAGMA temp_store = MEMORY;")
                db.execSQL("PRAGMA cache_size = -64000;")
                db.execSQL("PRAGMA mmap_size = 268435456;")
            } catch (e: Exception) {
                android.util.Log.w("AppDatabase", "Error setting performance PRAGMAs: ${e.message}")
            }
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_channels_playlistId ON channels(playlistId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_channels_type ON channels(type)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_channels_playlist_type ON channels(playlistId, type)")
            
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS watch_progress (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlistId INTEGER,
                    contentType TEXT,
                    showId TEXT,
                    seasonNumber INTEGER,
                    episodeNumber INTEGER,
                    episodeId TEXT,
                    title TEXT,
                    posterUrl TEXT,
                    positionMs INTEGER,
                    durationMs INTEGER,
                    lastWatchedAt INTEGER
                )
            """)
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS raw_cache (
                    cacheKey TEXT PRIMARY KEY,
                    playlistId INTEGER,
                    rawData TEXT,
                    updatedAt INTEGER
                )
            """)
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS epg_cache (
                    cacheKey TEXT PRIMARY KEY,
                    epgData TEXT,
                    date TEXT,
                    updatedAt INTEGER
                )
            """)
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_raw_cache_playlistId ON raw_cache(playlistId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_epg_cache_date ON epg_cache(date)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_watch_progress_playlist_ep ON watch_progress(playlistId, episodeId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_watch_progress_last_watched ON watch_progress(lastWatchedAt DESC)")
            
            // Auto-migration for existing databases without triggering SQLiteLog errors
            addColumnIfNotExists(db, "playlists", "ipAddress", "TEXT")
            addColumnIfNotExists(db, "playlists", "customIp", "TEXT")
            addColumnIfNotExists(db, "playlists", "isActive", "INTEGER DEFAULT 1")
            
            addColumnIfNotExists(db, "channels", "hasCatchup", "INTEGER DEFAULT 0")
            addColumnIfNotExists(db, "channels", "tvArchiveDuration", "INTEGER DEFAULT 0")
            addColumnIfNotExists(db, "channels", "tvArchiveType", "TEXT")
            addColumnIfNotExists(db, "channels", "allowLocalTimeshift", "INTEGER DEFAULT 0")
            addColumnIfNotExists(db, "channels", "archiveDate", "TEXT")
            addColumnIfNotExists(db, "channels", "allowPvr", "INTEGER DEFAULT 0")
            addColumnIfNotExists(db, "channels", "stalkerId", "TEXT")
        }

        private fun addColumnIfNotExists(db: SQLiteDatabase, tableName: String, columnName: String, columnDef: String) {
            var exists = false
            try {
                db.rawQuery("PRAGMA table_info($tableName)", null).use { c ->
                    val nameCol = c.getColumnIndex("name")
                    while (c.moveToNext()) {
                        if (nameCol != -1 && columnName.equals(c.getString(nameCol), ignoreCase = true)) {
                            exists = true
                            break
                        }
                    }
                }
            } catch (e: Exception) {}

            if (!exists) {
                try {
                    db.execSQL("ALTER TABLE $tableName ADD COLUMN $columnName $columnDef")
                } catch (e: Exception) {}
            }
        }
    }
}

class PlaylistDao(private val helper: SQLiteOpenHelper) {
    private val _playlistsFlow = MutableStateFlow<List<PlaylistItem>>(emptyList())
    
    init {
        refresh()
    }
    
    fun refresh() {
        val db = helper.readableDatabase
        val list = mutableListOf<PlaylistItem>()
        val cursor = db.rawQuery("SELECT * FROM playlists ORDER BY id DESC", null)
        cursor.use {
            val idCol = it.getColumnIndex("id")
            val nameCol = it.getColumnIndex("name")
            val typeCol = it.getColumnIndex("type")
            val urlCol = it.getColumnIndex("url")
            val userCol = it.getColumnIndex("username")
            val passCol = it.getColumnIndex("password")
            val macCol = it.getColumnIndex("macAddress")
            val ipCol = it.getColumnIndex("ipAddress")
            val customIpCol = it.getColumnIndex("customIp")
            val activeCol = it.getColumnIndex("isActive")
            
            while (it.moveToNext()) {
                val isActiveVal = if (activeCol != -1) it.getInt(activeCol) == 1 else true
                list.add(
                    PlaylistItem(
                        id = it.getLong(idCol),
                        name = it.getString(nameCol) ?: "",
                        type = it.getString(typeCol) ?: "",
                        url = it.getString(urlCol) ?: "",
                        username = it.getString(userCol),
                        password = it.getString(passCol),
                        macAddress = it.getString(macCol),
                        ipAddress = if (ipCol != -1) it.getString(ipCol) else null,
                        customIp = if (customIpCol != -1) it.getString(customIpCol) else null,
                        isActive = isActiveVal
                    )
                )
            }
        }
        _playlistsFlow.value = list
    }
    
    fun getAllPlaylists(): Flow<List<PlaylistItem>> {
        return _playlistsFlow.asStateFlow()
    }

    fun getAllPlaylistsSync(): List<PlaylistItem> {
        return _playlistsFlow.value
    }
    
    fun getPlaylistById(playlistId: Long): PlaylistItem? {
        val db = helper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM playlists WHERE id = ?", arrayOf(playlistId.toString()))
        cursor.use {
            if (it.moveToFirst()) {
                val idCol = it.getColumnIndex("id")
                val nameCol = it.getColumnIndex("name")
                val typeCol = it.getColumnIndex("type")
                val urlCol = it.getColumnIndex("url")
                val userCol = it.getColumnIndex("username")
                val passCol = it.getColumnIndex("password")
                val macCol = it.getColumnIndex("macAddress")
                val ipCol = it.getColumnIndex("ipAddress")
                val customIpCol = it.getColumnIndex("customIp")
                val activeCol = it.getColumnIndex("isActive")
                
                return PlaylistItem(
                    id = it.getLong(idCol),
                    name = it.getString(nameCol) ?: "",
                    type = it.getString(typeCol) ?: "",
                    url = it.getString(urlCol) ?: "",
                    username = it.getString(userCol),
                    password = it.getString(passCol),
                    macAddress = it.getString(macCol),
                    ipAddress = if (ipCol != -1) it.getString(ipCol) else null,
                    customIp = if (customIpCol != -1) it.getString(customIpCol) else null,
                    isActive = if (activeCol != -1) it.getInt(activeCol) == 1 else true
                )
            }
        }
        return null
    }

    fun getPlaylistByMac(mac: String): PlaylistItem? {
        val db = helper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM playlists WHERE macAddress = ? LIMIT 1", arrayOf(mac))
        cursor.use {
            if (it.moveToFirst()) {
                val idCol = it.getColumnIndex("id")
                val nameCol = it.getColumnIndex("name")
                val typeCol = it.getColumnIndex("type")
                val urlCol = it.getColumnIndex("url")
                val userCol = it.getColumnIndex("username")
                val passCol = it.getColumnIndex("password")
                val macCol = it.getColumnIndex("macAddress")
                val ipCol = it.getColumnIndex("ipAddress")
                val customIpCol = it.getColumnIndex("customIp")
                val activeCol = it.getColumnIndex("isActive")
                
                return PlaylistItem(
                    id = it.getLong(idCol),
                    name = it.getString(nameCol) ?: "",
                    type = it.getString(typeCol) ?: "",
                    url = it.getString(urlCol) ?: "",
                    username = it.getString(userCol),
                    password = it.getString(passCol),
                    macAddress = it.getString(macCol),
                    ipAddress = if (ipCol != -1) it.getString(ipCol) else null,
                    customIp = if (customIpCol != -1) it.getString(customIpCol) else null,
                    isActive = if (activeCol != -1) it.getInt(activeCol) == 1 else true
                )
            }
        }
        return null
    }
    
    fun insertPlaylist(playlist: PlaylistItem): Long {
        val db = helper.writableDatabase
        val values = ContentValues().apply {
            put("name", playlist.name)
            put("type", playlist.type)
            put("url", playlist.url)
            put("username", playlist.username)
            put("password", playlist.password)
            put("macAddress", playlist.macAddress)
            put("ipAddress", playlist.ipAddress)
            put("customIp", playlist.customIp)
            put("isActive", if (playlist.isActive) 1 else 0)
        }
        val id = db.insert("playlists", null, values)
        refresh()
        return id
    }
    
    fun deletePlaylist(playlistId: Long) {
        val db = helper.writableDatabase
        db.delete("playlists", "id = ?", arrayOf(playlistId.toString()))
        refresh()
    }

    fun deleteAllPlaylists() {
        val db = helper.writableDatabase
        db.delete("playlists", null, null)
        refresh()
    }

    fun updatePlaylist(playlist: PlaylistItem) {
        val db = helper.writableDatabase
        val values = ContentValues().apply {
            put("name", playlist.name)
            put("type", playlist.type)
            put("url", playlist.url)
            put("username", playlist.username)
            put("password", playlist.password)
            put("macAddress", playlist.macAddress)
            put("ipAddress", playlist.ipAddress)
            put("customIp", playlist.customIp)
            put("isActive", if (playlist.isActive) 1 else 0)
        }
        db.update("playlists", values, "id = ?", arrayOf(playlist.id.toString()))
        refresh()
    }

    fun updatePlaylistActiveState(playlistId: Long, isActive: Boolean) {
        val db = helper.writableDatabase
        val values = ContentValues().apply {
            put("isActive", if (isActive) 1 else 0)
        }
        db.update("playlists", values, "id = ?", arrayOf(playlistId.toString()))
        refresh()
    }
}

class ChannelDao(private val helper: SQLiteOpenHelper) {
    private val _channelsMap = mutableMapOf<Long, MutableStateFlow<List<ChannelItem>>>()

    private fun getFlowForPlaylist(playlistId: Long): MutableStateFlow<List<ChannelItem>> {
        return synchronized(_channelsMap) {
            _channelsMap.getOrPut(playlistId) {
                MutableStateFlow(queryChannels(playlistId))
            }
        }
    }

    private fun queryChannels(playlistId: Long): List<ChannelItem> {
        val db = helper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM channels WHERE playlistId = ? ORDER BY id ASC", arrayOf(playlistId.toString()))
        cursor.use {
            val list = ArrayList<ChannelItem>(it.count)
            val idCol = it.getColumnIndex("id")
            val plCol = it.getColumnIndex("playlistId")
            val nameCol = it.getColumnIndex("name")
            val logoCol = it.getColumnIndex("logoUrl")
            val streamCol = it.getColumnIndex("streamUrl")
            val groupCol = it.getColumnIndex("groupName")
            val typeCol = it.getColumnIndex("type")
            val catchupCol = it.getColumnIndex("hasCatchup")
            val durationCol = it.getColumnIndex("tvArchiveDuration")
            val archiveTypeCol = it.getColumnIndex("tvArchiveType")
            val localTimeshiftCol = it.getColumnIndex("allowLocalTimeshift")
            val archiveDateCol = it.getColumnIndex("archiveDate")
            val allowPvrCol = it.getColumnIndex("allowPvr")
            val stalkerIdCol = it.getColumnIndex("stalkerId")
            
            while (it.moveToNext()) {
                val hasCatchupVal = if (catchupCol != -1) it.getInt(catchupCol) == 1 else false
                val durationVal = if (durationCol != -1) it.getInt(durationCol) else 0
                val archiveTypeVal = if (archiveTypeCol != -1) it.getString(archiveTypeCol) ?: "" else ""
                val localTimeshiftVal = if (localTimeshiftCol != -1) it.getInt(localTimeshiftCol) else 0
                val archiveDateVal = if (archiveDateCol != -1) it.getString(archiveDateCol) ?: "" else ""
                val allowPvrVal = if (allowPvrCol != -1) it.getInt(allowPvrCol) else 0
                val stalkerIdVal = if (stalkerIdCol != -1) it.getString(stalkerIdCol) ?: "" else ""

                list.add(
                    ChannelItem(
                        id = it.getLong(idCol),
                        playlistId = it.getLong(plCol),
                        name = it.getString(nameCol) ?: "",
                        logoUrl = it.getString(logoCol) ?: "",
                        streamUrl = it.getString(streamCol) ?: "",
                        groupName = it.getString(groupCol) ?: "",
                        type = it.getString(typeCol) ?: "Live",
                        hasCatchup = hasCatchupVal,
                        tvArchiveDuration = durationVal,
                        tvArchiveType = archiveTypeVal,
                        allowLocalTimeshift = localTimeshiftVal,
                        archiveDate = archiveDateVal,
                        allowPvr = allowPvrVal,
                        stalkerId = stalkerIdVal
                    )
                )
            }
            return list
        }
    }

    fun queryChannelsDirect(playlistId: Long): List<ChannelItem> {
        return queryChannels(playlistId)
    }

    fun getChannelsForPlaylist(playlistId: Long): Flow<List<ChannelItem>> {
        val flow = getFlowForPlaylist(playlistId)
        flow.value = queryChannels(playlistId) // Refresh on query
        return flow.asStateFlow()
    }

    fun notifyPlaylistChanged(playlistId: Long) {
        try {
            getFlowForPlaylist(playlistId).value = queryChannels(playlistId)
        } catch (e: Exception) {
            android.util.Log.e("ChannelDao", "Error notifying playlist changed: ${e.message}", e)
        }
    }

    fun insertChannels(channels: List<ChannelItem>, notify: Boolean = true) {
        if (channels.isEmpty()) return
        val db = helper.writableDatabase
        val sql = "INSERT INTO channels (playlistId, name, logoUrl, streamUrl, groupName, type, hasCatchup, tvArchiveDuration, tvArchiveType, allowLocalTimeshift, archiveDate, allowPvr, stalkerId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        val stmt = db.compileStatement(sql)
        
        val chunks = channels.chunked(2500)
        for (chunk in chunks) {
            db.beginTransactionNonExclusive()
            try {
                for (ch in chunk) {
                    stmt.clearBindings()
                    stmt.bindLong(1, ch.playlistId)
                    stmt.bindString(2, ch.name ?: "")
                    stmt.bindString(3, ch.logoUrl ?: "")
                    stmt.bindString(4, ch.streamUrl ?: "")
                    stmt.bindString(5, ch.groupName ?: "")
                    stmt.bindString(6, ch.type ?: "Live")
                    stmt.bindLong(7, if (ch.hasCatchup) 1L else 0L)
                    stmt.bindLong(8, ch.tvArchiveDuration.toLong())
                    stmt.bindString(9, ch.tvArchiveType ?: "")
                    stmt.bindLong(10, ch.allowLocalTimeshift.toLong())
                    stmt.bindString(11, ch.archiveDate ?: "")
                    stmt.bindLong(12, ch.allowPvr.toLong())
                    stmt.bindString(13, ch.stalkerId ?: "")
                    stmt.executeInsert()
                }
                db.setTransactionSuccessful()
            } catch (e: Exception) {
                android.util.Log.e("ChannelDao", "Error inserting channel chunk: ${e.message}", e)
            } finally {
                db.endTransaction()
            }
        }
        stmt.close()
        
        if (notify) {
            // Notify affected playlists
            val affectedPlaylists = java.util.HashSet<Long>()
            for (ch in channels) {
                affectedPlaylists.add(ch.playlistId)
            }
            for (plId in affectedPlaylists) {
                notifyPlaylistChanged(plId)
            }
        }
    }

    fun deleteChannelsByPlaylist(playlistId: Long) {
        val db = helper.writableDatabase
        db.delete("channels", "playlistId = ?", arrayOf(playlistId.toString()))
        getFlowForPlaylist(playlistId).value = emptyList()
    }

    fun deleteAllChannels() {
        val db = helper.writableDatabase
        db.delete("channels", null, null)
        synchronized(_channelsMap) {
            for (flow in _channelsMap.values) {
                flow.value = emptyList()
            }
            _channelsMap.clear()
        }
    }

    fun getPlaylistSummary(playlistId: Long): Triple<Int, Int, Int> {
        val db = helper.readableDatabase
        var liveCount = 0
        var movieCount = 0
        var seriesCount = 0
        val cursor = db.rawQuery(
            "SELECT type, COUNT(*) FROM channels WHERE playlistId = ? GROUP BY type",
            arrayOf(playlistId.toString())
        )
        cursor.use {
            while (it.moveToNext()) {
                val type = it.getString(0) ?: "Live"
                val count = it.getInt(1)
                when (type) {
                    "Live" -> liveCount = count
                    "Movie" -> movieCount = count
                    "Series" -> seriesCount = count
                }
            }
        }
        return Triple(liveCount, movieCount, seriesCount)
    }
}

class HistoryDao(private val helper: SQLiteOpenHelper) {
    private val _historyFlow = MutableStateFlow<List<HistoryItem>>(emptyList())
    
    init {
        refresh()
    }
    
    fun refresh() {
        val db = helper.readableDatabase
        val list = mutableListOf<HistoryItem>()
        val cursor = db.rawQuery("SELECT * FROM history ORDER BY timestamp DESC LIMIT 50", null)
        cursor.use {
            val idCol = it.getColumnIndex("id")
            val plCol = it.getColumnIndex("playlistId")
            val nameCol = it.getColumnIndex("channelName")
            val streamCol = it.getColumnIndex("streamUrl")
            val tsCol = it.getColumnIndex("timestamp")
            
            while (it.moveToNext()) {
                list.add(
                    HistoryItem(
                        id = it.getLong(idCol),
                        playlistId = it.getLong(plCol),
                        channelName = it.getString(nameCol) ?: "",
                        streamUrl = it.getString(streamCol) ?: "",
                        timestamp = it.getLong(tsCol)
                    )
                )
            }
        }
        _historyFlow.value = list
    }
    
    fun getRecentHistory(): Flow<List<HistoryItem>> {
        return _historyFlow.asStateFlow()
    }
    
    fun insertHistory(item: HistoryItem) {
        val db = helper.writableDatabase
        db.delete("history", "streamUrl = ?", arrayOf(item.streamUrl))
        val values = ContentValues().apply {
            put("playlistId", item.playlistId)
            put("channelName", item.channelName)
            put("streamUrl", item.streamUrl)
            put("timestamp", item.timestamp)
        }
        db.insert("history", null, values)
        refresh()
    }
    
    fun clearHistory() {
        val db = helper.writableDatabase
        db.delete("history", null, null)
        refresh()
    }
}

class FavoriteDao(private val helper: SQLiteOpenHelper) {
    
    fun isFavorite(playlistId: Long, url: String): Boolean {
        val db = helper.readableDatabase
        val cursor = db.rawQuery("SELECT id FROM favorites WHERE playlistId = ? AND streamUrl = ? LIMIT 1", arrayOf(playlistId.toString(), url))
        cursor.use {
            return it.moveToFirst()
        }
    }
    
    fun insertFavorite(item: FavoriteItem) {
        val db = helper.writableDatabase
        db.delete("favorites", "playlistId = ? AND streamUrl = ?", arrayOf(item.playlistId.toString(), item.streamUrl))
        val values = ContentValues().apply {
            put("playlistId", item.playlistId)
            put("channelName", item.channelName)
            put("streamUrl", item.streamUrl)
        }
        db.insert("favorites", null, values)
    }
    
    fun deleteFavorite(playlistId: Long, url: String) {
        val db = helper.writableDatabase
        db.delete("favorites", "playlistId = ? AND streamUrl = ?", arrayOf(playlistId.toString(), url))
    }
}

class RecordingDao(private val helper: SQLiteOpenHelper) {
    private val _recordingsFlow = MutableStateFlow<List<RecordingItem>>(emptyList())
    
    init {
        refresh()
    }
    
    fun refresh() {
        val db = helper.readableDatabase
        val list = mutableListOf<RecordingItem>()
        val cursor = db.rawQuery("SELECT * FROM recordings ORDER BY scheduledAt DESC", null)
        cursor.use {
            val idCol = it.getColumnIndex("id")
            val plCol = it.getColumnIndex("playlistId")
            val chCol = it.getColumnIndex("channelName")
            val streamCol = it.getColumnIndex("streamUrl")
            val pathCol = it.getColumnIndex("filepath")
            val titleCol = it.getColumnIndex("programTitle")
            val schedCol = it.getColumnIndex("scheduledAt")
            val durCol = it.getColumnIndex("durationMinutes")
            val compCol = it.getColumnIndex("isCompleted")
            
            while (it.moveToNext()) {
                list.add(
                    RecordingItem(
                        id = it.getLong(idCol),
                        playlistId = it.getLong(plCol),
                        channelName = it.getString(chCol) ?: "",
                        streamUrl = it.getString(streamCol) ?: "",
                        filepath = it.getString(pathCol) ?: "",
                        programTitle = it.getString(titleCol) ?: "",
                        scheduledAt = it.getLong(schedCol),
                        durationMinutes = it.getInt(durCol),
                        isCompleted = it.getInt(compCol) == 1
                    )
                )
            }
        }
        _recordingsFlow.value = list
    }
    
    fun getAllRecordings(): Flow<List<RecordingItem>> {
        return _recordingsFlow.asStateFlow()
    }
    
    fun insertRecording(recording: RecordingItem): Long {
        val db = helper.writableDatabase
        val values = ContentValues().apply {
            put("playlistId", recording.playlistId)
            put("channelName", recording.channelName)
            put("streamUrl", recording.streamUrl)
            put("filepath", recording.filepath)
            put("programTitle", recording.programTitle)
            put("scheduledAt", recording.scheduledAt)
            put("durationMinutes", recording.durationMinutes)
            put("isCompleted", if (recording.isCompleted) 1 else 0)
        }
        val id = db.insert("recordings", null, values)
        refresh()
        return id
    }
    
    fun deleteRecording(id: Long) {
        val db = helper.writableDatabase
        db.delete("recordings", "id = ?", arrayOf(id.toString()))
        refresh()
    }
}

class WatchProgressDao(private val helper: SQLiteOpenHelper) {
    private val _watchProgressFlow = MutableStateFlow<List<WatchProgress>>(emptyList())

    init {
        refresh()
    }

    fun refresh() {
        val db = helper.readableDatabase
        val list = mutableListOf<WatchProgress>()
        val cursor = db.rawQuery("SELECT * FROM watch_progress ORDER BY lastWatchedAt DESC LIMIT 100", null)
        cursor.use {
            val idCol = it.getColumnIndex("id")
            val plCol = it.getColumnIndex("playlistId")
            val typeCol = it.getColumnIndex("contentType")
            val showCol = it.getColumnIndex("showId")
            val seasonCol = it.getColumnIndex("seasonNumber")
            val epNumCol = it.getColumnIndex("episodeNumber")
            val epIdCol = it.getColumnIndex("episodeId")
            val titleCol = it.getColumnIndex("title")
            val posterCol = it.getColumnIndex("posterUrl")
            val posCol = it.getColumnIndex("positionMs")
            val durCol = it.getColumnIndex("durationMs")
            val lastCol = it.getColumnIndex("lastWatchedAt")

            while (it.moveToNext()) {
                list.add(
                    WatchProgress(
                        id = it.getLong(idCol),
                        playlistId = it.getLong(plCol),
                        contentType = it.getString(typeCol) ?: "movie",
                        showId = it.getString(showCol) ?: "",
                        seasonNumber = it.getInt(seasonCol),
                        episodeNumber = it.getInt(epNumCol),
                        episodeId = it.getString(epIdCol) ?: "",
                        title = it.getString(titleCol) ?: "",
                        posterUrl = it.getString(posterCol) ?: "",
                        positionMs = it.getLong(posCol),
                        durationMs = it.getLong(durCol),
                        lastWatchedAt = it.getLong(lastCol)
                    )
                )
            }
        }
        _watchProgressFlow.value = list
    }

    fun getRecentWatchProgress(limit: Int = 2): Flow<List<WatchProgress>> {
        refresh()
        return _watchProgressFlow.asStateFlow()
    }

    fun getWatchProgress(playlistId: Long, episodeId: String): WatchProgress? {
        val db = helper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM watch_progress WHERE playlistId = ? AND episodeId = ? LIMIT 1", arrayOf(playlistId.toString(), episodeId))
        cursor.use {
            if (it.moveToFirst()) {
                val idCol = it.getColumnIndex("id")
                val plCol = it.getColumnIndex("playlistId")
                val typeCol = it.getColumnIndex("contentType")
                val showCol = it.getColumnIndex("showId")
                val seasonCol = it.getColumnIndex("seasonNumber")
                val epNumCol = it.getColumnIndex("episodeNumber")
                val epIdCol = it.getColumnIndex("episodeId")
                val titleCol = it.getColumnIndex("title")
                val posterCol = it.getColumnIndex("posterUrl")
                val posCol = it.getColumnIndex("positionMs")
                val durCol = it.getColumnIndex("durationMs")
                val lastCol = it.getColumnIndex("lastWatchedAt")

                return WatchProgress(
                    id = it.getLong(idCol),
                    playlistId = it.getLong(plCol),
                    contentType = it.getString(typeCol) ?: "movie",
                    showId = it.getString(showCol) ?: "",
                    seasonNumber = it.getInt(seasonCol),
                    episodeNumber = it.getInt(epNumCol),
                    episodeId = it.getString(epIdCol) ?: "",
                    title = it.getString(titleCol) ?: "",
                    posterUrl = it.getString(posterCol) ?: "",
                    positionMs = it.getLong(posCol),
                    durationMs = it.getLong(durCol),
                    lastWatchedAt = it.getLong(lastCol)
                )
            }
        }
        return null
    }

    fun upsert(item: WatchProgress) {
        val db = helper.writableDatabase
        db.delete("watch_progress", "playlistId = ? AND episodeId = ?", arrayOf(item.playlistId.toString(), item.episodeId))
        val values = ContentValues().apply {
            put("playlistId", item.playlistId)
            put("contentType", item.contentType)
            put("showId", item.showId)
            put("seasonNumber", item.seasonNumber)
            put("episodeNumber", item.episodeNumber)
            put("episodeId", item.episodeId)
            put("title", item.title)
            put("posterUrl", item.posterUrl)
            put("positionMs", item.positionMs)
            put("durationMs", item.durationMs)
            put("lastWatchedAt", item.lastWatchedAt)
        }
        db.insert("watch_progress", null, values)
        // Keep recent watch progress history up to 200 records
        db.execSQL("DELETE FROM watch_progress WHERE id NOT IN (SELECT id FROM watch_progress ORDER BY lastWatchedAt DESC LIMIT 200)")
        refresh()
    }

    fun deleteWatchProgress(playlistId: Long, episodeId: String) {
        val db = helper.writableDatabase
        db.delete("watch_progress", "playlistId = ? AND episodeId = ?", arrayOf(playlistId.toString(), episodeId))
        refresh()
    }

    fun deleteWatchProgressById(id: Long) {
        val db = helper.writableDatabase
        db.delete("watch_progress", "id = ?", arrayOf(id.toString()))
        refresh()
    }

    fun clearAllWatchProgress() {
        val db = helper.writableDatabase
        db.delete("watch_progress", null, null)
        refresh()
    }
}

class RawCacheDao(private val helper: SQLiteOpenHelper) {
    fun getRaw(cacheKey: String): String? {
        return try {
            val db = helper.readableDatabase
            db.rawQuery("SELECT rawData FROM raw_cache WHERE cacheKey = ?", arrayOf(cacheKey)).use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(0)
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun getRawWithTimestamp(cacheKey: String): Pair<String, Long>? {
        return try {
            val db = helper.readableDatabase
            db.rawQuery("SELECT rawData, updatedAt FROM raw_cache WHERE cacheKey = ?", arrayOf(cacheKey)).use { cursor ->
                if (cursor.moveToFirst()) {
                    Pair(cursor.getString(0) ?: "", cursor.getLong(1))
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun saveRaw(cacheKey: String, playlistId: Long, rawData: String) {
        try {
            val db = helper.writableDatabase
            val values = ContentValues().apply {
                put("cacheKey", cacheKey)
                put("playlistId", playlistId)
                put("rawData", rawData)
                put("updatedAt", System.currentTimeMillis())
            }
            db.insertWithOnConflict("raw_cache", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        } catch (e: Exception) {
            android.util.Log.e("RawCacheDao", "Failed to save raw cache: ${e.message}")
        }
    }

    fun deleteForPlaylist(playlistId: Long) {
        try {
            val db = helper.writableDatabase
            db.delete("raw_cache", "playlistId = ?", arrayOf(playlistId.toString()))
        } catch (e: Exception) {
            android.util.Log.e("RawCacheDao", "Failed to delete raw cache: ${e.message}")
        }
    }

    fun clearAll() {
        try {
            val db = helper.writableDatabase
            db.delete("raw_cache", null, null)
        } catch (e: Exception) {
            android.util.Log.e("RawCacheDao", "Failed to clear raw cache: ${e.message}")
        }
    }
}

class EpgCacheDao(private val helper: SQLiteOpenHelper) {
    fun getEpg(cacheKey: String): String? {
        return try {
            val db = helper.readableDatabase
            db.rawQuery("SELECT epgData FROM epg_cache WHERE cacheKey = ?", arrayOf(cacheKey)).use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(0)
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun getEpgWithDate(cacheKey: String, date: String): String? {
        return try {
            val db = helper.readableDatabase
            db.rawQuery("SELECT epgData FROM epg_cache WHERE cacheKey = ? AND (date = ? OR date = '')", arrayOf(cacheKey, date)).use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(0)
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun saveEpg(cacheKey: String, epgData: String, date: String = "") {
        try {
            val db = helper.writableDatabase
            val values = ContentValues().apply {
                put("cacheKey", cacheKey)
                put("epgData", epgData)
                put("date", date)
                put("updatedAt", System.currentTimeMillis())
            }
            db.insertWithOnConflict("epg_cache", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        } catch (e: Exception) {
            android.util.Log.e("EpgCacheDao", "Failed to save EPG cache: ${e.message}")
        }
    }

    fun clearOldEpg(olderThanMs: Long = 7 * 24 * 3600 * 1000L) {
        try {
            val db = helper.writableDatabase
            val cutoff = System.currentTimeMillis() - olderThanMs
            db.delete("epg_cache", "updatedAt < ?", arrayOf(cutoff.toString()))
        } catch (e: Exception) {
            android.util.Log.e("EpgCacheDao", "Failed to clear old EPG cache: ${e.message}")
        }
    }
}
