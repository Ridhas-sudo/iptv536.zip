package com.example.data

import android.util.Log
import android.net.Uri
import okhttp3.ConnectionSpec
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import org.json.JSONArray
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Intercepteur intelligent pour contourner et surmonter tous les problèmes serveurs :
 * - 301, 302, 303, 307, 308 (Redirections directes, multi-protocoles HTTP/HTTPS, cookies préservés)
 * - 401, 403 (Blocages User-Agent, Referer manquant, anti-bots)
 * - 456, 429 (Limitation serveur Stalker/IPTV, renouvellement de session)
 * - 500, 502, 503, 504 (Passerelles et erreurs réseau transitoires)
 */
class ServerBypassInterceptor : Interceptor {
    companion object {
        private val FALLBACK_USER_AGENTS = listOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "VLC/3.0.18 LibVLC/3.0.18",
            "IPTVSmartersPro",
            "TiviMate/4.7.0",
            "Kodi/20.2 (Linux; Android 11)",
            "AppleCoreMedia/1.0.0.19G69 (Apple TV; U; CPU OS 15_6 like Mac OS X; en_us)",
            "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        )
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        
        // Inject Referer & Origin if missing to bypass server anti-hotlinking
        val host = request.url.host
        val builder = request.newBuilder()
        if (request.header("Referer").isNullOrEmpty()) {
            builder.header("Referer", "${request.url.scheme}://$host/")
        }
        if (request.header("Origin").isNullOrEmpty()) {
            builder.header("Origin", "${request.url.scheme}://$host")
        }
        if (request.header("User-Agent").isNullOrEmpty()) {
            builder.header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
        }
        if (request.header("Accept").isNullOrEmpty()) {
            builder.header("Accept", "*/*")
        }
        request = builder.build()

        var response: Response
        var retryCount = 0
        val maxRetries = 6

        while (true) {
            try {
                response = chain.proceed(request)
            } catch (e: Exception) {
                if (retryCount < 2) {
                    retryCount++
                    try { Thread.sleep(200) } catch (_: Exception) {}
                    continue
                } else {
                    throw e
                }
            }

            val code = response.code

            // 1. GESTION DES REDIRECTIONS 301, 302, 303, 307, 308 (Multi-protocoles & Cross-Domain)
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val location = response.header("Location")
                if (!location.isNullOrBlank() && retryCount < maxRetries) {
                    retryCount++
                    response.close()
                    val newUrl = request.url.resolve(location)
                    if (newUrl != null) {
                        val redirectRequestBuilder = request.newBuilder().url(newUrl)
                        val cookies = response.headers("Set-Cookie")
                        if (cookies.isNotEmpty()) {
                            val existingCookie = request.header("Cookie") ?: ""
                            val newCookieHeader = buildString {
                                if (existingCookie.isNotEmpty()) append(existingCookie).append("; ")
                                append(cookies.joinToString("; ") { it.substringBefore(";") })
                            }
                            redirectRequestBuilder.header("Cookie", newCookieHeader)
                        }
                        request = redirectRequestBuilder.build()
                        continue
                    }
                }
            }

            // 2. GESTION DES ERREURS 401, 403 (User-Agent bloqué ou Anti-Bot)
            if ((code == 401 || code == 403) && retryCount < 4) {
                val currentUa = request.header("User-Agent") ?: ""
                val nextUa = FALLBACK_USER_AGENTS.firstOrNull { it != currentUa }
                if (nextUa != null) {
                    retryCount++
                    response.close()
                    try { Thread.sleep(150) } catch (_: Exception) {}
                    request = request.newBuilder()
                        .header("User-Agent", nextUa)
                        .header("Referer", "${request.url.scheme}://${request.url.host}/")
                        .build()
                    continue
                }
            }

            // 3. GESTION DES ERREURS 406 (Not Acceptable - Rejet des en-têtes Accept ou encodage par le serveur IPTV)
            if (code == 406 && retryCount < 4) {
                retryCount++
                response.close()
                val fallbackAccept = when (retryCount) {
                    1 -> "*/*"
                    2 -> "video/*, audio/*, application/x-mpegURL, application/vnd.apple.mpegurl, */*"
                    else -> "*/*"
                }
                val fallbackUa = when (retryCount) {
                    1 -> "VLC/3.0.18 LibVLC/3.0.18"
                    2 -> "AppleCoreMedia/1.0.0.19G69 (Apple TV; U; CPU OS 15_6 like Mac OS X; en_us)"
                    else -> "IPTVSmartersPro"
                }
                request = request.newBuilder()
                    .header("Accept", fallbackAccept)
                    .header("User-Agent", fallbackUa)
                    .removeHeader("Accept-Encoding")
                    .removeHeader("Accept-Language")
                    .build()
                try { Thread.sleep(150) } catch (_: Exception) {}
                continue
            }

            // 4. GESTION DES ERREURS 460 (Client Closed Request / Timeout Passerelle CDN Load Balancer)
            if (code == 460 && retryCount < 4) {
                retryCount++
                response.close()
                try { Thread.sleep(250L * retryCount) } catch (_: Exception) {}
                request = request.newBuilder()
                    .header("Connection", "close")
                    .header("User-Agent", "TiviMate/4.7.0")
                    .removeHeader("Keep-Alive")
                    .build()
                continue
            }

            // 5. GESTION DES ERREURS 456 (Limite / Reset de session Stalker) OU 429 (Trop de requêtes)
            if ((code == 456 || code == 429) && retryCount < 3) {
                retryCount++
                response.close()
                try {
                    Thread.sleep(350L * retryCount)
                } catch (_: Exception) {}
                continue
            }

            // 6. GESTION DES ERREURS SERVEURS 500, 502, 503, 504 (Passerelles IPTV saturées)
            if ((code == 500 || code == 502 || code == 503 || code == 504) && retryCount < 2) {
                retryCount++
                response.close()
                try {
                    Thread.sleep(400L * retryCount)
                } catch (_: Exception) {}
                continue
            }

            break
        }

        return response
    }
}

class StalkerHeaderInterceptor : Interceptor {
    companion object {
        @Volatile
        var currentMac: String = "00:1A:79:78:25:F1"
        
        @Volatile
        var currentToken: String = ""
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val url = originalRequest.url
        val path = url.encodedPath
        
        // Try to extract MAC address from headers or query parameters
        var mac = originalRequest.header("X-Stalker-Mac") ?: originalRequest.header("X-MAC")
        
        if (mac.isNullOrEmpty()) {
            mac = url.queryParameter("mac")
        }
        
        if (mac.isNullOrEmpty()) {
            val cookieHeader = originalRequest.header("Cookie")
            if (cookieHeader != null) {
                val match = Regex("mac=([^;\\s]+)").find(cookieHeader)
                if (match != null) {
                    mac = match.groupValues[1]
                }
            }
        }
        
        if (mac.isNullOrEmpty()) {
            val userCardHeader = originalRequest.header("X-User-Card")
            if (userCardHeader != null) {
                val match = Regex("mac=([^;\\s]+)").find(userCardHeader)
                if (match != null) {
                    mac = match.groupValues[1]
                }
            }
        }
        
        val isStalker = path.contains("/server/load.php") || 
                        path.contains("portal.php") ||
                        path.contains("stalker_portal") || 
                        !originalRequest.header("X-Stalker-Mac").isNullOrEmpty() || 
                        !originalRequest.header("X-MAC").isNullOrEmpty() || 
                        !url.queryParameter("mac").isNullOrEmpty() || 
                        !mac.isNullOrEmpty()
                        
        if (!isStalker) {
            return chain.proceed(originalRequest)
        }
        
        val finalMac = if (!mac.isNullOrEmpty()) {
            val formatted = formatMacAddress(mac.replace("\"", "").replace("'", "").trim())
            currentMac = formatted
            formatted
        } else {
            formatMacAddress(currentMac)
        }

        var token = url.queryParameter("token") ?: currentToken
        if (token.startsWith("mock_token_")) {
            token = ""
        }

        val deviceFields = generateStalkerDeviceFields(finalMac)
        val devId = deviceFields["device_id"] ?: ""
        val devId2 = deviceFields["device_id2"] ?: ""
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val cookieVal = StringBuilder("mac=$finalMac; stb_lang=en; timezone=Europe/Paris")
        if (token.isNotEmpty()) {
            cookieVal.append("; token=$token")
        }

        // Retrieve customIp from database if available
        val playlist = AppDatabase.appContext?.let { ctx ->
            try {
                AppDatabase.getDatabase(ctx).playlistDao().getPlaylistByMac(finalMac)
            } catch (e: Exception) {
                null
            }
        }
        val customIp = (playlist?.customIp?.trim() ?: playlist?.ipAddress?.trim() ?: "").trim()
        val isValidIpv4 = { ip: String ->
            val regex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
            regex.matches(ip)
        }
        val hasCustomIp = customIp.isNotEmpty() && isValidIpv4(customIp)

        val userCardVal = if (hasCustomIp) {
            "mac=$finalMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial; ip=$customIp"
        } else {
            "mac=$finalMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
        }

        val requestBuilder = originalRequest.newBuilder()
            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("X-User-Card", userCardVal)
            .header("Cookie", cookieVal.toString())
            .header("Accept", "*/*")
            .header("Accept-Language", "en-US,fr-FR;q=0.9,en;q=0.8")
            .removeHeader("X-Stalker-Mac")
            .removeHeader("X-MAC")

        if (hasCustomIp) {
            requestBuilder.header("X-Forwarded-For", customIp)
            requestBuilder.header("X-Real-IP", customIp)
            requestBuilder.header("Client-IP", customIp)
        } else {
            requestBuilder.removeHeader("X-Forwarded-For")
            requestBuilder.removeHeader("X-Real-IP")
            requestBuilder.removeHeader("Client-IP")
        }

        if (token.isNotEmpty()) {
            requestBuilder.header("Authorization", "Bearer $token")
        }

        val request = requestBuilder.build()
        
        try {
            var response = chain.proceed(request)
            if (response.code == 401 || response.code == 403) {
                Log.d("STALKER_DEBUG", "[Interceptor] Got ${response.code} (Token Expired). Attempting auto-handshake refresh...")
                response.close()
                
                // Perform a new handshake synchronously to get a fresh token
                val apiService = ApiService(getUnsafeOkHttpClientWithoutInterceptor())
                val cleanUrl = if (url.toString().contains("/server/load.php")) {
                    url.toString().substringBefore("server/load.php")
                } else if (url.toString().contains("/portal.php")) {
                    url.toString().substringBefore("portal.php")
                } else {
                    url.toString().substringBefore("?")
                }
                
                try {
                    val handshakeResult = apiService.performHandshake(cleanUrl, finalMac)
                    if (handshakeResult.token.isNotEmpty() && !handshakeResult.token.startsWith("mock_token_")) {
                        Log.d("STALKER_DEBUG", "[Interceptor] Token refreshed successfully: ${handshakeResult.token}")
                        currentToken = handshakeResult.token
                        
                        // Rebuild request with new token
                        val newRequestBuilder = request.newBuilder()
                            .header("Authorization", "Bearer ${handshakeResult.token}")
                            
                        val newCookieVal = StringBuilder("mac=$finalMac; stb_lang=en; timezone=Europe/Paris")
                        newCookieVal.append("; token=${handshakeResult.token}")
                        newRequestBuilder.header("Cookie", newCookieVal.toString())
                        
                        // Also update token in URL query parameter if present
                        if (url.queryParameter("token") != null) {
                            val newUrl = url.newBuilder().setQueryParameter("token", handshakeResult.token).build()
                            newRequestBuilder.url(newUrl)
                        }
                        
                        response = chain.proceed(newRequestBuilder.build())
                    }
                } catch (e: Exception) {
                    Log.e("STALKER_DEBUG", "[Interceptor] Token auto-refresh failed: ${e.message}")
                }
            }
            
            if (!response.isSuccessful) {
                val responseCode = response.code
                val responseBodyString = try {
                    response.peekBody(1024 * 1024).string()
                } catch (e: Exception) {
                    "Could not read body: ${e.message}"
                }
                Log.e("STALKER_DEBUG", "[HTTP Failure] URL: ${request.url}, Code: $responseCode, Body: $responseBodyString")
            }
            return response
        } catch (e: Exception) {
            Log.e("STALKER_DEBUG", "[HTTP Exception] URL: ${request.url}, Error: ${e.message}", e)
            throw e
        }
    }
}

class StalkerSyncSession(
    @Volatile var currentToken: String,
    @Volatile var currentBaseUrl: String,
    val macAddress: String,
    val ipAddress: String?,
    val apiService: ApiService
) {
    val mutex = Mutex()

    suspend fun refreshTokenIfNeeded(failedToken: String): String {
        mutex.withLock {
            if (currentToken != failedToken && currentToken.isNotEmpty() && !currentToken.startsWith("mock_token_")) {
                Log.d("StalkerRepository", "Token was already refreshed by another thread in this sync session. Reusing new token=$currentToken")
                return currentToken
            }
            Log.d("StalkerRepository", "Authorization failed detected during sync. Performing single synchronized handshake...")
            try {
                val cleanMac = formatMacAddress(macAddress).uppercase()
                val (newToken, newEndpoint) = apiService.executeStalkerAuthFlow(cleanMac, currentBaseUrl, ipAddress)
                if (newToken.isNotEmpty()) {
                    currentToken = newToken
                    val cacheKeyBase = if (currentBaseUrl.endsWith("/")) currentBaseUrl else "$currentBaseUrl/"
                    apiService.updateHandshakeCache(cacheKeyBase, cleanMac, newToken, newEndpoint)
                    Log.d("StalkerRepository", "Single synchronized handshake completed. New token=$newToken")
                } else {
                    Log.e("StalkerRepository", "Single synchronized handshake failed to return a valid token.")
                }
            } catch (e: Exception) {
                Log.e("StalkerRepository", "Error during synchronized handshake: ${e.message}")
            }
            return currentToken
        }
    }
}

class StalkerSyncSessionInterceptor(private val session: StalkerSyncSession) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        val url = request.url
        val reqToken = url.queryParameter("token") ?: session.currentToken
        
        // If token in session was already updated by another coroutine, replace token in request before sending
        if (session.currentToken != reqToken && session.currentToken.isNotEmpty()) {
            val newUrl = url.newBuilder().setQueryParameter("token", session.currentToken).build()
            val newRequestBuilder = request.newBuilder().url(newUrl)
            newRequestBuilder.header("Authorization", "Bearer ${session.currentToken}")
            val cookieHeader = request.header("Cookie")
            if (cookieHeader != null) {
                val updatedCookie = cookieHeader.replace(Regex("token=[^;]*"), "token=${session.currentToken}")
                newRequestBuilder.header("Cookie", updatedCookie)
            }
            request = newRequestBuilder.build()
        }

        var response = chain.proceed(request)
        
        val peekBody = try { response.peekBody(2048).string() } catch (e: Exception) { "" }
        val isAuthFailed = response.code == 401 || response.code == 403 || 
                           peekBody.contains("Authorization failed", ignoreCase = true) ||
                           peekBody.contains("authorization_failed", ignoreCase = true) ||
                           peekBody.contains("wrong token", ignoreCase = true)

        if (isAuthFailed) {
            Log.d("StalkerRepository", "[SyncSessionInterceptor] Auth failure detected (${response.code}). Triggering synchronized single handshake...")
            response.close()
            
            val newToken = kotlinx.coroutines.runBlocking {
                session.refreshTokenIfNeeded(reqToken)
            }
            
            if (newToken.isNotEmpty() && newToken != reqToken) {
                val newUrl = url.newBuilder().setQueryParameter("token", newToken).build()
                val newRequestBuilder = request.newBuilder().url(newUrl)
                    .header("Authorization", "Bearer $newToken")
                val cookieHeader = request.header("Cookie")
                if (cookieHeader != null) {
                    val updatedCookie = cookieHeader.replace(Regex("token=[^;]*"), "token=$newToken")
                    newRequestBuilder.header("Cookie", updatedCookie)
                }
                response = chain.proceed(newRequestBuilder.build())
            }
        }
        return response
    }
}

private val sharedConnectionPool = okhttp3.ConnectionPool(64, 5, java.util.concurrent.TimeUnit.MINUTES)

private val sharedUnsafeOkHttpClient: OkHttpClient by lazy {
    buildSharedUnsafeOkHttpClient(withStalkerInterceptor = true)
}

private val sharedUnsafeOkHttpClientWithoutInterceptor: OkHttpClient by lazy {
    buildSharedUnsafeOkHttpClient(withStalkerInterceptor = false)
}

private fun buildSharedUnsafeOkHttpClient(withStalkerInterceptor: Boolean): OkHttpClient {
    try {
        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        })

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCerts, java.security.SecureRandom())
        val sslSocketFactory = sslContext.socketFactory

        val connectionSpecs = listOf(
            ConnectionSpec.MODERN_TLS,
            ConnectionSpec.COMPATIBLE_TLS,
            ConnectionSpec.CLEARTEXT
        )

        val builder = OkHttpClient.Builder()
            .sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            .hostnameVerifier { _, _ -> true }
            .connectionSpecs(connectionSpecs)
            .connectionPool(sharedConnectionPool)
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(if (withStalkerInterceptor) 15 else 30, TimeUnit.SECONDS)
            .readTimeout(if (withStalkerInterceptor) 20 else 60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .addInterceptor(ServerBypassInterceptor())
            .addInterceptor(com.example.debug.GlobalDebugSystem.createOkHttpInterceptor())

        if (withStalkerInterceptor) {
            builder.addInterceptor(StalkerHeaderInterceptor())
        }

        return builder.build()
    } catch (e: Exception) {
        throw RuntimeException(e)
    }
}

fun getUnsafeOkHttpClient(): OkHttpClient {
    return sharedUnsafeOkHttpClient
}

fun getUnsafeOkHttpClientWithoutInterceptor(): OkHttpClient {
    return sharedUnsafeOkHttpClientWithoutInterceptor
}

fun formatMacAddress(mac: String): String {
    val clean = mac.trim().replace("-", ":").replace(".", ":").replace(" ", "").replace("\"", "").replace("'", "").uppercase()
    val hexOnly = clean.replace(":", "")
    if (hexOnly.length == 12) {
        return hexOnly.chunked(2).joinToString(":")
    }
    return clean
}

fun md5(input: String): String {
    return try {
        val md = java.security.MessageDigest.getInstance("MD5")
        val bytes = md.digest(input.toByteArray())
        bytes.joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        val hash = input.hashCode().coerceAtLeast(0).toString().padEnd(16, '0')
        "a1b2c3d4e5f67890$hash"
    }
}

fun sha1(input: String): String {
    return try {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        val bytes = md.digest(input.toByteArray())
        bytes.joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        val hash = input.hashCode().coerceAtLeast(0).toString().padEnd(40, '0')
        hash.padEnd(40, '0').take(40)
    }
}

fun generateStalkerDeviceFields(mac: String): Map<String, String> {
    val cleanMac = mac.replace(":", "").uppercase()
    val md5Mac = md5(cleanMac)
    val md5Mac2 = md5(cleanMac + "device_id2")
    val md5Sig = md5(cleanMac + "signature")
    
    val lastSix = if (cleanMac.length >= 6) cleanMac.substring(cleanMac.length - 6) else "041750"
    val serial = "062014N$lastSix"
    val prehash = sha1(cleanMac + serial)
    val hwVersion2 = sha1(cleanMac + serial + "hw2")
    
    return mapOf(
        "device_id" to md5Mac,
        "device_id2" to md5Mac2,
        "signature" to md5Sig,
        "serial_number" to serial,
        "prehash" to prehash,
        "hw_version_2" to hwVersion2
    )
}

fun buildStalkerGetProfileUrl(baseUrl: String, endpoint: String, mac: String, token: String): String {
    val cleanMac = formatMacAddress(mac).uppercase()
    val fields = generateStalkerDeviceFields(cleanMac)
    val serial = fields["serial_number"] ?: ""
    val prehash = fields["prehash"] ?: ""
    val hwVersion2 = fields["hw_version_2"] ?: ""
    val randomSha1 = sha1(java.util.UUID.randomUUID().toString() + System.currentTimeMillis())
    val timestamp = System.currentTimeMillis() / 1000L

    val encSn = java.net.URLEncoder.encode(serial, "UTF-8")
    val encToken = java.net.URLEncoder.encode(token, "UTF-8")
    val verStr = "ImageDescription: 0.2.18-r19-pub-250; ImageDate: Mon Jun 12 11:04:49 EEST 2017; PORTAL version: 5.6.8; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x588"
    val encVer = java.net.URLEncoder.encode(verStr, "UTF-8").replace("+", "%20")
    val metricsJson = """{"mac":"$cleanMac","sn":"$serial","model":"MAG250","type":"STB","uid":"","random":"$randomSha1"}"""
    val encMetrics = java.net.URLEncoder.encode(metricsJson, "UTF-8").replace("+", "%20")

    val url = "${baseUrl}${endpoint}?type=stb&action=get_profile" +
            "&hd=1" +
            "&ver=$encVer" +
            "&num_banks=2" +
            "&sn=$encSn" +
            "&stb_type=MAG250" +
            "&client_type=STB" +
            "&image_version=218" +
            "&video_out=hdmi" +
            "&device_id=" +
            "&device_id2=" +
            "&signature=" +
            "&auth_second_step=1" +
            "&hw_version=1.7-BD-00" +
            "&not_valid_token=0" +
            "&metrics=$encMetrics" +
            "&hw_version_2=$hwVersion2" +
            "&timestamp=$timestamp" +
            "&api_signature=262" +
            "&prehash=$prehash" +
            "&token=$encToken" +
            "&JsHttpRequest=1-xml"

    Log.d("STALKER_AUTH", "Generated get_profile URL: $url")
    return url
}

fun resolveStalkerPortalUrl(portalUrl: String, mac: String): String {
    var cleanUrl = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
    try {
        val cleanMac = formatMacAddress(mac)
        val deviceFields = generateStalkerDeviceFields(cleanMac)
        val devId = deviceFields["device_id"] ?: ""
        var devId2 = deviceFields["device_id2"] ?: ""
        if (portalUrl.contains("deirnet.ps", ignoreCase = true)) {
            devId2 = ""
        }
        val headers = mapOf(
            "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp main release 0.2.18",
            "X-User-Agent" to "Model: MAG250; Link: WiFi",
            "X-User-Card" to "mac=$cleanMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=${deviceFields["signature"]}; serial_number=${deviceFields["serial_number"]}",
            "Cookie" to "mac=$cleanMac; stb_lang=en; timezone=Europe/Paris; ad=1",
            "Accept" to "*/*"
        )
        
        val resolved = resolveRedirects(cleanUrl, headers)
        return if (resolved.endsWith("/")) resolved else "$resolved/"
    } catch (e: Exception) {
        Log.e("ApiService", "Failed to resolve stalker portal URL: ${e.message}")
    }
    return cleanUrl
}

data class HandshakeResult(
    val token: String,
    val resolvedUrl: String,
    val usedMac: String,
    val endpointPath: String = "server/load.php"
) {
    val endpointFileName: String get() = endpointPath
}

fun cleanStalkerJson(body: String): String {
    var cleaned = body.trim()
    // Remove UTF-8 BOM if present
    if (cleaned.startsWith("\uFEFF")) {
        cleaned = cleaned.substring(1)
    }
    // Remove any leading/trailing javascript comments or function wrappers
    if (cleaned.startsWith("/*") && cleaned.endsWith("*/")) {
        cleaned = cleaned.substring(2, cleaned.length - 2).trim()
    }
    
    val firstBrace = cleaned.indexOf('{')
    val firstBracket = cleaned.indexOf('[')
    val lastBrace = cleaned.lastIndexOf('}')
    val lastBracket = cleaned.lastIndexOf(']')
    
    val start = if (firstBrace != -1 && (firstBracket == -1 || firstBrace < firstBracket)) firstBrace else firstBracket
    val end = if (lastBrace != -1 && (lastBracket == -1 || lastBrace > lastBracket)) lastBrace else lastBracket
    
    if (start != -1 && end != -1 && end > start) {
        return cleaned.substring(start, end + 1)
    }
    return cleaned
}

fun convertJsonObjectToCcArray(obj: JSONObject): org.json.JSONArray {
    val arr = org.json.JSONArray()
    val keys = mutableListOf<String>()
    val iter = obj.keys()
    while (iter.hasNext()) {
        keys.add(iter.next())
    }
    val sortedKeys = keys.sortedWith(Comparator { a, b ->
        val aInt = a.toIntOrNull()
        val bInt = b.toIntOrNull()
        if (aInt != null && bInt != null) {
            aInt.compareTo(bInt)
        } else {
            a.compareTo(b)
        }
    })
    for (k in sortedKeys) {
        val item = obj.opt(k)
        if (item != null) {
            arr.put(item)
        }
    }
    return arr
}

fun cleanAndExtractStalkerArray(body: String): org.json.JSONArray? {
    val cleaned = cleanStalkerJson(body)
    if (cleaned.isEmpty()) return null
    try {
        if (cleaned.startsWith("[")) {
            return org.json.JSONArray(cleaned)
        }
        val json = JSONObject(cleaned)
        
        // Comprehensive check of known Stalker list/array keys
        val jsArray = json.optJSONArray("js")
            ?: json.optJSONObject("js")?.optJSONArray("data")
            ?: json.optJSONObject("js")?.optJSONArray("series")
            ?: json.optJSONObject("js")?.optJSONArray("genres")
            ?: json.optJSONObject("js")?.optJSONArray("categories")
            ?: json.optJSONObject("js")?.optJSONArray("channels")
            ?: json.optJSONObject("js")?.optJSONArray("channel_list")
            ?: json.optJSONObject("js")?.optJSONArray("rows")
            ?: json.optJSONObject("js")?.optJSONArray("media")
            ?: json.optJSONObject("js")?.optJSONArray("vod")
            ?: json.optJSONObject("js")?.optJSONArray("list")
            ?: json.optJSONObject("js")?.optJSONArray("results")
            ?: json.optJSONObject("js")?.optJSONArray("items")
            ?: json.optJSONArray("result")
            ?: json.optJSONObject("result")?.optJSONArray("data")
            ?: json.optJSONObject("result")?.optJSONArray("series")
            ?: json.optJSONObject("result")?.optJSONArray("genres")
            ?: json.optJSONObject("result")?.optJSONArray("categories")
            ?: json.optJSONObject("result")?.optJSONArray("channels")
            ?: json.optJSONObject("result")?.optJSONArray("channel_list")
            ?: json.optJSONObject("result")?.optJSONArray("rows")
            ?: json.optJSONObject("result")?.optJSONArray("media")
            ?: json.optJSONObject("result")?.optJSONArray("vod")
            ?: json.optJSONObject("result")?.optJSONArray("list")
            ?: json.optJSONObject("result")?.optJSONArray("results")
            ?: json.optJSONObject("result")?.optJSONArray("items")
            ?: json.optJSONArray("data")
            ?: json.optJSONArray("series")
            ?: json.optJSONArray("genres")
            ?: json.optJSONArray("categories")
            ?: json.optJSONArray("channels")
            ?: json.optJSONArray("channel_list")
            ?: json.optJSONArray("rows")
            ?: json.optJSONArray("media")
            ?: json.optJSONArray("vod")
            ?: json.optJSONArray("list")
            ?: json.optJSONArray("results")
            ?: json.optJSONArray("items")
            
        if (jsArray != null) return jsArray

        val jsObj = json.optJSONObject("js") ?: json.optJSONObject("result")
        if (jsObj != null) {
            val nestedData = jsObj.optJSONObject("data") ?: jsObj.optJSONObject("results")
            if (nestedData != null) {
                val converted = convertJsonObjectToCcArray(nestedData)
                if (converted.length() > 0) return converted
            }
            val converted = convertJsonObjectToCcArray(jsObj)
            if (converted.length() > 0) return converted
        }

        // Also check if root has data or results object
        val rootDataObj = json.optJSONObject("data") ?: json.optJSONObject("results")
        if (rootDataObj != null) {
            val converted = convertJsonObjectToCcArray(rootDataObj)
            if (converted.length() > 0) return converted
        }
        
        // Dynamic fallback: scan all keys
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val arr = json.optJSONArray(key)
            if (arr != null) return arr
            val obj = json.optJSONObject(key)
            if (obj != null) {
                val converted = convertJsonObjectToCcArray(obj)
                if (converted.length() > 0) return converted
                
                val subKeys = obj.keys()
                while (subKeys.hasNext()) {
                    val subKey = subKeys.next()
                    val subArr = obj.optJSONArray(subKey)
                    if (subArr != null) return subArr
                    
                    val subObj = obj.optJSONObject(subKey)
                    if (subObj != null) {
                        val subConverted = convertJsonObjectToCcArray(subObj)
                        if (subConverted.length() > 0) return subConverted
                    }
                }
            }
        }
    } catch (e: Throwable) {
        Log.e("StalkerParser", "Failed to parse Stalker array: ${e.message}\nBody snippet: ${if (body.length > 200) body.take(200) + "..." else body}")
    }
    return null
}

fun resolveRedirects(url: String, headers: Map<String, String>): String {
    if (url.isBlank() || url.startsWith("file://") || (!url.startsWith("http://") && !url.startsWith("https://"))) return url
    try {
        val client = getUnsafeOkHttpClient().newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .build()
            
        var currentUrl = url
        var redirects = 0
        while (redirects < 6) {
            val requestBuilder = Request.Builder().url(currentUrl)
            for ((k, v) in headers) {
                requestBuilder.header(k, v)
            }
            try {
                var isRedirect = false
                var redirectLocation: String? = null
                
                client.newCall(requestBuilder.build()).execute().use { response ->
                    val code = response.code
                    val location = response.header("Location")
                    
                    if ((code == 301 || code == 302 || code == 303 || code == 307 || code == 308) && !location.isNullOrEmpty()) {
                        isRedirect = true
                        redirectLocation = location.trim()
                    }
                }
                
                if (isRedirect && redirectLocation != null) {
                    var nextUrl = redirectLocation!!
                    if (!nextUrl.startsWith("http://") && !nextUrl.startsWith("https://")) {
                        val uri = java.net.URI(currentUrl)
                        nextUrl = uri.resolve(nextUrl).toString()
                    }
                    currentUrl = nextUrl
                    redirects++
                } else {
                    break
                }
            } catch (e: Exception) {
                Log.e("IPTV_REDIRECT", "Error during redirect check for $currentUrl: ${e.message}")
                break
            }
        }
        Log.d("IPTV_REDIRECT", "Resolved final URL: $currentUrl after $redirects redirects")
        return currentUrl
    } catch (e: Exception) {
        Log.e("IPTV_REDIRECT", "Error resolving redirects for $url: ${e.message}")
        return url
    }
}

class ApiService(private val client: OkHttpClient) {

    companion object {
        private val handshakeCache = java.util.concurrent.ConcurrentHashMap<String, HandshakeResult>()
        val authMutex = Mutex()
        private val handshakeCounter = java.util.concurrent.atomic.AtomicInteger(0)

        fun resetHandshakeCounter() {
            handshakeCounter.set(0)
        }

        fun incrementHandshakeCounter(): Int {
            return handshakeCounter.incrementAndGet()
        }

        fun getHandshakeCount(): Int {
            return handshakeCounter.get()
        }
    }

    private fun tryGetProfile(
        baseUrl: String,
        endpointPath: String,
        token: String,
        mac: String,
        userAgent: String,
        xUserAgent: String
    ): Boolean {
        try {
            val url = buildStalkerGetProfileUrl(baseUrl, endpointPath, mac, token)
            val deviceFields = generateStalkerDeviceFields(mac)
            val devId = deviceFields["device_id"] ?: ""
            val devId2 = deviceFields["device_id2"] ?: ""
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("X-User-Agent", xUserAgent)
                .header("X-User-Card", "mac=$mac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                .header("Cookie", "mac=$mac; stb_lang=en; timezone=Europe/Paris")
                .header("Authorization", "Bearer $token")
                .header("Accept", "*/*")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                Log.d("STALKER_DEBUG", "[Profile Request] URL: $url, HTTP: ${response.code}, Response: ${if (body.length > 500) body.take(500) + "..." else body}")
                if (response.isSuccessful) {
                    val cleaned = cleanStalkerJson(body)
                    if (cleaned.isNotEmpty()) {
                        val json = JSONObject(cleaned)
                        if (json.has("error")) {
                            Log.e("STALKER_DEBUG", "[Profile Validation] Error field in response: ${json.optString("error")}")
                            return false
                        }
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("STALKER_DEBUG", "[Profile Validation] Error calling get_profile: ${e.message}")
        }
        return false
    }

    private fun tryHandshake(portalUrl: String, mac: String): HandshakeResult? {
        try {
            val cleanUrl = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
            val cleanMac = formatMacAddress(mac).uppercase()
            val deviceFields = generateStalkerDeviceFields(cleanMac)
            val prehash = deviceFields["prehash"] ?: ""
            
            val queryParams = listOf(
                "type=stb&action=handshake&prehash=$prehash&mac=$mac&JsHttpRequest=1-xml",
                "type=itv&action=handshake&prehash=$prehash&mac=$mac&JsHttpRequest=1-xml",
                "type=stb&action=handshake&prehash=$prehash&mac=$mac&JsHttpRequest=1",
                "type=itv&action=handshake&prehash=$prehash&mac=$mac&JsHttpRequest=1",
                "type=stb&action=handshake&prehash=$prehash&mac=$mac",
                "type=itv&action=handshake&prehash=$prehash&mac=$mac"
            )
            
            val paths = listOf("server/load.php", "portal.php")
            
            val models = listOf(
                Triple("MAG250", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3", "Model: MAG250; Link: WiFi"),
                Triple("MAG254", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3", "Model: MAG254; Link: WiFi"),
                Triple("MAG322", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3", "Model: MAG322; Link: WiFi")
            )
            
            for (model in models) {
                val modelName = model.first
                val userAgent = model.second
                val xUserAgent = model.third
                
                for (path in paths) {
                    for (qp in queryParams) {
                        val handshakeUrl = "${cleanUrl}${path}?$qp"
                        Log.d("STALKER_DEBUG", "--> [STALKER HANDSHAKE ATTEMPT] URL: $handshakeUrl with $modelName, MAC: $mac")
                        
                        val deviceFields = generateStalkerDeviceFields(mac)
                        val devId = deviceFields["device_id"] ?: ""
                        var devId2 = deviceFields["device_id2"] ?: ""
                        if (cleanUrl.contains("deirnet.ps", ignoreCase = true)) {
                            devId2 = ""
                        }
                        val sig = deviceFields["signature"] ?: ""
                        val serial = deviceFields["serial_number"] ?: ""

                        val request = Request.Builder()
                            .url(handshakeUrl)
                            .header("User-Agent", userAgent)
                            .header("X-User-Agent", xUserAgent)
                            .header("X-User-Card", "mac=$mac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                            .header("Cookie", "mac=$mac; stb_lang=en; timezone=Europe/Paris")
                            .header("Referer", cleanUrl)
                            .header("Accept", "*/*")
                            .header("Accept-Language", "en-US,fr-FR;q=0.9,en;q=0.8")
                            .header("X-Forwarded-For", "8.8.8.8")
                            .build()
                            
                        try {
                            client.newCall(request).execute().use { response ->
                                val finalUrl = response.request.url.toString()
                                val resolvedBaseUrl = extractBaseUrl(finalUrl, cleanUrl)
                                
                                if (response.isSuccessful) {
                                    val body = response.body?.string() ?: ""
                                    Log.d("STALKER_DEBUG", "<-- [STALKER HANDSHAKE HTTP SUCCESS] URL: $handshakeUrl, HTTP: ${response.code}")
                                    Log.d("STALKER_DEBUG", "Body: ${if (body.length > 1000) body.take(1000) + "..." else body}")
                                    if (body.isEmpty()) {
                                        return@use
                                    }
                                    
                                    val cleanedBody = cleanStalkerJson(body)
                                    var token = ""
                                    val json = try {
                                        JSONObject(cleanedBody)
                                    } catch (e: Exception) {
                                        Log.e("STALKER_DEBUG", "JSON parse error: ${e.message}")
                                        null
                                    }
                                    
                                    if (json != null) {
                                        if (json.has("js")) {
                                            val jsObj = json.optJSONObject("js")
                                            if (jsObj != null) {
                                                token = jsObj.optString("token")
                                            } else {
                                                token = json.optString("js")
                                            }
                                        }
                                        if (token.isEmpty() && json.has("token")) {
                                            token = json.optString("token")
                                        }
                                        if (token.isEmpty() && json.has("result")) {
                                            val resObj = json.optJSONObject("result")
                                            if (resObj != null) {
                                                token = resObj.optString("token")
                                            } else {
                                                token = json.optString("result")
                                            }
                                        }
                                    }
                                    
                                    if (token.isEmpty()) {
                                        val tokenRegex = Regex("""["']?token["']?\s*:\s*["']([^"']+)["']""")
                                        val match = tokenRegex.find(body)
                                        if (match != null) {
                                            token = match.groupValues[1]
                                        }
                                    }
                                    
                                    if (token.isNotEmpty()) {
                                        Log.d("STALKER_DEBUG", "[STALKER TOKEN DETECTED] Token: $token. Testing token with get_profile...")
                                        StalkerHeaderInterceptor.currentToken = token
                                        
                                        // Verify token immediately via get_profile standard requirement
                                        val verified = tryGetProfile(resolvedBaseUrl, path, token, mac, userAgent, xUserAgent)
                                        if (verified) {
                                            Log.d("STALKER_DEBUG", "================ [STALKER HANDSHAKE SUCCESS & VERIFIED] ================")
                                            Log.d("STALKER_DEBUG", "Token: $token")
                                            Log.d("STALKER_DEBUG", "Base URL: $resolvedBaseUrl")
                                            Log.d("STALKER_DEBUG", "Path: $path")
                                            Log.d("STALKER_DEBUG", "=======================================================================")
                                            return HandshakeResult(token, resolvedBaseUrl, mac, path)
                                        } else {
                                            Log.w("STALKER_DEBUG", "[STALKER TOKEN REJECTED] Token $token was returned, but get_profile was rejected or errored.")
                                        }
                                    }
                                } else {
                                    Log.d("STALKER_DEBUG", "<-- [STALKER HANDSHAKE HTTP FAIL] URL: $handshakeUrl, HTTP: ${response.code}")
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("STALKER_DEBUG", "Handshake request error for $handshakeUrl: ${e.message}")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("STALKER_DEBUG", "Handshake exception for $portalUrl: ${e.message}")
        }
        return null
    }

    private fun extractBaseUrl(requestUrl: String, defaultUrl: String): String {
        var index = requestUrl.indexOf("server/load.php")
        if (index != -1) {
            return requestUrl.substring(0, index)
        }
        index = requestUrl.indexOf("portal.php")
        if (index != -1) {
            return requestUrl.substring(0, index)
        }
        return defaultUrl
    }

class StalkerNetworkCutException(message: String, cause: Throwable? = null) : java.io.IOException(message, cause)
class StalkerHttpErrorException(val httpCode: Int, message: String) : Exception(message)

    fun getCandidatePortalUrls(portalUrl: String): List<String> {
        val candidates = mutableListOf<String>()
        var clean = portalUrl.trim()
        
        // Strip query parameters and fragment
        if (clean.contains("?")) {
            clean = clean.substringBefore("?")
        }
        if (clean.contains("#")) {
            clean = clean.substringBefore("#")
        }
        
        val schemes = if (clean.startsWith("https://", ignoreCase = true)) {
            listOf("https://", "http://")
        } else if (clean.startsWith("http://", ignoreCase = true)) {
            listOf("http://", "https://")
        } else {
            clean = "http://$clean"
            listOf("http://", "https://")
        }

        for (scheme in schemes) {
            var currentUrl = if (clean.startsWith("http://", ignoreCase = true)) {
                scheme + clean.substring("http://".length)
            } else if (clean.startsWith("https://", ignoreCase = true)) {
                scheme + clean.substring("https://".length)
            } else {
                scheme + clean
            }

            // Normalize and remove trailing slash for stripping
            if (currentUrl.endsWith("/")) {
                currentUrl = currentUrl.dropLast(1)
            }

            // Strip common filenames/paths
            val stripPatterns = listOf(
                "/server/load.php", "/load.php", "/portal.php", "/index.html", "/index.php", "/c/index.html", "/c/index.php", "/c"
            )
            var stripped = true
            while (stripped) {
                stripped = false
                for (pattern in stripPatterns) {
                    if (currentUrl.endsWith(pattern, ignoreCase = true)) {
                        currentUrl = currentUrl.substring(0, currentUrl.length - pattern.length)
                        stripped = true
                    }
                }
            }
            
            if (!currentUrl.endsWith("/")) {
                currentUrl += "/"
            }
            
            var base = currentUrl
            var baseWithoutPort = base
            try {
                val uri = java.net.URI(currentUrl)
                val s = uri.scheme ?: scheme.removeSuffix("://")
                val authority = uri.authority ?: ""
                base = "$s://$authority/"
                val host = uri.host ?: ""
                if (host.isNotEmpty()) {
                    baseWithoutPort = "$s://$host/"
                }
            } catch (e: Exception) {
                val parts = currentUrl.split("://")
                if (parts.size == 2) {
                    val hostPart = parts[1].substringBefore("/")
                    base = "${parts[0]}://$hostPart/"
                    val hostOnly = hostPart.substringBefore(":")
                    baseWithoutPort = "${parts[0]}://$hostOnly/"
                }
            }
            
            // 1. TOUTE PREMIÈRE POSITION : racine du domaine + portal.php (sans aucun sous-dossier)
            candidates.add("${base}portal.php")
            if (baseWithoutPort != base) {
                candidates.add("${baseWithoutPort}portal.php")
            }

            // 2. Racine pure du domaine
            candidates.add(base)
            if (baseWithoutPort != base) {
                candidates.add(baseWithoutPort)
            }
            
            // 3. URL brute utilisateur (si différente)
            val rawCandidate = if (portalUrl.trim().endsWith("/")) portalUrl.trim() else "${portalUrl.trim()}/"
            candidates.add(rawCandidate)
            candidates.add(currentUrl)
            
            // 4. Variantes Stalker avec sous-dossiers en repli
            candidates.add("${base}c/")
            candidates.add("${base}stalker_portal/c/")
            candidates.add("${base}stalker_portal/")
            candidates.add("${base}server/")
            candidates.add("${base}ministra/")
            candidates.add("${base}mag/")
            
            // Add subfolder variations if currentUrl != base
            if (currentUrl != base && currentUrl != baseWithoutPort) {
                val subBase = currentUrl
                candidates.add(subBase)
                if (!subBase.endsWith("/c/")) candidates.add("${subBase}c/")
                if (!subBase.endsWith("/stalker_portal/")) candidates.add("${subBase}stalker_portal/")
                if (!subBase.endsWith("/stalker_portal/c/")) candidates.add("${subBase}stalker_portal/c/")
            }
        }

        return candidates.map { if (it.endsWith(".php", ignoreCase = true) || it.endsWith("/")) it else "$it/" }.distinct()
    }

    fun getHandshakeCache(): java.util.concurrent.ConcurrentHashMap<String, HandshakeResult> {
        return handshakeCache
    }

    fun updateHandshakeCache(baseUrl: String, mac: String, token: String, endpointFile: String) {
        val cleanMac = formatMacAddress(mac).uppercase()
        val fullResolvedBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val result = HandshakeResult(token, fullResolvedBase, cleanMac, endpointFile)
        val keysToCache = listOf(
            "$baseUrl|$cleanMac",
            "${if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"}|$cleanMac",
            "${baseUrl.trimEnd('/')}|$cleanMac",
            "$fullResolvedBase|$cleanMac"
        ).distinct()
        for (k in keysToCache) {
            handshakeCache[k] = result
        }
        StalkerHeaderInterceptor.currentMac = cleanMac
        StalkerHeaderInterceptor.currentToken = token
    }

    suspend fun executeSingleSyncHandshake(mac: String, baseUrl: String, ipAddress: String? = null): HandshakeResult = withContext(Dispatchers.IO) {
        val cleanMac = formatMacAddress(mac).uppercase()
        val (token, workingEndpoint) = executeStalkerAuthFlow(cleanMac, baseUrl, ipAddress)
        if (token.isEmpty()) {
            throw Exception("Échec de l'authentification Stalker (token vide) sur $baseUrl")
        }
        val fullResolvedBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val result = HandshakeResult(token, fullResolvedBase, cleanMac, workingEndpoint)
        updateHandshakeCache(baseUrl, cleanMac, token, workingEndpoint)
        return@withContext result
    }

    private fun fetchPriorSessionCookie(mac: String, baseUrl: String, ipAddress: String? = null): String {
        val cleanMac = formatMacAddress(mac).uppercase()
        val deviceFields = generateStalkerDeviceFields(cleanMac)
        val devId = deviceFields["device_id"] ?: ""
        var devId2 = deviceFields["device_id2"] ?: ""
        if (baseUrl.contains("deirnet.ps", ignoreCase = true)) {
            devId2 = ""
        }
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val userAgent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        val xUserAgent = "Model: MAG250; Link: WiFi"

        val isValidIpv4 = { ip: String ->
            val regex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
            regex.matches(ip)
        }
        val customIp = ipAddress?.trim() ?: ""
        val hasCustomIp = customIp.isNotEmpty() && isValidIpv4(customIp)

        val userCardVal = if (hasCustomIp) {
            "mac=$cleanMac; stb_lang=en; timezone=GMT; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial; ip=$customIp"
        } else {
            "mac=$cleanMac; stb_lang=en; timezone=GMT; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
        }

        var normalizedBase = baseUrl.trim()
        if (normalizedBase.endsWith("server/load.php")) {
            normalizedBase = normalizedBase.removeSuffix("server/load.php")
        } else if (normalizedBase.endsWith("portal.php")) {
            normalizedBase = normalizedBase.removeSuffix("portal.php")
        }
        if (!normalizedBase.endsWith("/")) {
            normalizedBase += "/"
        }

        val handshakeClient = getUnsafeOkHttpClientWithoutInterceptor().newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        var sessionCookie = ""
        val priorStartTime = System.currentTimeMillis()
        try {
            val priorRequestBuilder = Request.Builder()
                .url(normalizedBase)
                .header("User-Agent", userAgent)
                .header("X-User-Agent", xUserAgent)
                .header("X-User-Card", userCardVal)
                .header("Cookie", "mac=$cleanMac; stb_lang=en; timezone=GMT")
                .header("Referer", normalizedBase)
                .header("Accept", "*/*")
                .header("Accept-Language", "en-US,fr-FR;q=0.9,en;q=0.8")

            if (hasCustomIp) {
                priorRequestBuilder.header("X-Forwarded-For", customIp)
                priorRequestBuilder.header("X-Real-IP", customIp)
                priorRequestBuilder.header("Client-IP", customIp)
            }

            handshakeClient.newCall(priorRequestBuilder.build()).execute().use { priorResp ->
                val elapsed = System.currentTimeMillis() - priorStartTime
                val setCookies = priorResp.headers("Set-Cookie")
                if (setCookies.isNotEmpty()) {
                    sessionCookie = setCookies.joinToString("; ") { cookieHeader ->
                        cookieHeader.substringBefore(";")
                    }
                    Log.d("PortalConnectDebug", "Prior session cookies obtained for $normalizedBase (${elapsed}ms): $sessionCookie")
                } else {
                    Log.d("PortalConnectDebug", "Prior session GET completed for $normalizedBase (${elapsed}ms) with no Set-Cookie header")
                }
            }
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - priorStartTime
            Log.d("PortalConnectDebug", "Prior session GET failed/timed out for $normalizedBase (${elapsed}ms): ${e.message}")
        }
        return sessionCookie
    }

    private fun isNetworkCutException(e: Throwable): Boolean {
        var curr: Throwable? = e
        while (curr != null) {
            if (curr is StalkerNetworkCutException) return true
            if (curr is StalkerHttpErrorException) return false
            if (curr is java.net.SocketException ||
                curr is java.net.ConnectException ||
                curr is java.net.SocketTimeoutException ||
                curr is java.net.UnknownHostException ||
                curr is javax.net.ssl.SSLException ||
                curr is java.io.EOFException ||
                curr is java.io.InterruptedIOException) {
                return true
            }
            curr = curr.cause
        }
        val msg = (e.message ?: "").lowercase()
        return msg.contains("failed to connect") ||
               msg.contains("connection refused") ||
               msg.contains("connection reset") ||
               msg.contains("broken pipe") ||
               msg.contains("unexpected end of stream") ||
               msg.contains("timeout") ||
               msg.contains("econnreset") ||
               msg.contains("econnrefused") ||
               msg.contains("injoignable")
    }

    suspend fun authenticateStalker(mac: String, url: String, ipAddress: String? = null): String = withContext(Dispatchers.IO) {
        val cleanMac = formatMacAddress(mac).uppercase()

        // 0. Vérifier d'abord si un token valide existe déjà en cache pour éviter d'invalider le flux vidéo en cours
        val cached = getCachedHandshakeResult(url, cleanMac)
        if (cached != null && !cached.token.startsWith("mock_token_") && cached.token.isNotBlank()) {
            Log.d("STALKER_AUTH", "authenticateStalker: Token en cache réutilisé immédiatement pour $url|$cleanMac")
            return@withContext cached.token
        }
        
        // Get candidate portal URLs with root domain + portal.php at the top
        val candidates = getCandidatePortalUrls(url)
        
        var lastException: Exception? = null
        var allTimedOut = true
        var consecutiveNetworkCuts = 0
        var isFirstCandidate = true
        
        // 1. Session préalable : GET sur la base URL exécuté QU'UNE SEULE FOIS avant la boucle des candidats
        val priorCookie = fetchPriorSessionCookie(cleanMac, url, ipAddress)
        
        for (candidateUrl in candidates) {
            if (!isFirstCandidate) {
                // 1. Délai d'au moins 400ms entre chaque tentative de candidat pour éviter le blocage anti-scan
                kotlinx.coroutines.delay(450)
            }
            isFirstCandidate = false

            Log.d("STALKER_AUTH", "Starting robust auth flow on candidate: $candidateUrl with MAC: $cleanMac, custom IP: $ipAddress")
            try {
                val (token, workingEndpoint) = executeStalkerAuthFlow(cleanMac, candidateUrl, ipAddress, priorCookie)
                if (token.isNotEmpty()) {
                    consecutiveNetworkCuts = 0
                    // Populate Cache
                    // IMPORTANT : normalise candidateUrl EXACTEMENT comme le fait executeStalkerAuthFlow
                    // en interne (retire portal.php/server/load.php/load.php de la fin) AVANT de
                    // construire fullResolvedBase, sinon un candidat de type "fichier" (ex:
                    // "http://domaine/portal.php") produirait une base corrompue du type
                    // "http://domaine/portal.php/" utilisée ensuite pour TOUS les appels suivants.
                    var normalizedCandidate = candidateUrl.trim()
                    if (normalizedCandidate.endsWith("server/load.php", ignoreCase = true)) {
                        normalizedCandidate = normalizedCandidate.dropLast("server/load.php".length)
                    } else if (normalizedCandidate.endsWith("portal.php", ignoreCase = true)) {
                        normalizedCandidate = normalizedCandidate.dropLast("portal.php".length)
                    } else if (normalizedCandidate.endsWith("load.php", ignoreCase = true)) {
                        normalizedCandidate = normalizedCandidate.dropLast("load.php".length)
                    }
                    val fullResolvedBase = if (normalizedCandidate.endsWith("/")) normalizedCandidate else "$normalizedCandidate/"
                    val handshakeResult = HandshakeResult(token, fullResolvedBase, cleanMac, workingEndpoint)
                    val keysToCache = listOf(
                        "$url|$cleanMac",
                        "${if (url.endsWith("/")) url else "$url/"}|$cleanMac",
                        "${url.trimEnd('/')}|$cleanMac",
                        "$candidateUrl|$cleanMac",
                        "$fullResolvedBase|$cleanMac",
                        "${candidateUrl.trimEnd('/')}|$cleanMac"
                    ).distinct()
                    for (k in keysToCache) {
                        handshakeCache[k] = handshakeResult
                    }
                    StalkerHeaderInterceptor.currentMac = cleanMac
                    StalkerHeaderInterceptor.currentToken = token
                    Log.d("STALKER_AUTH", "Successfully authenticated ($workingEndpoint) on full base URL '$fullResolvedBase' and cached handshake result for $url|$cleanMac. Arrêt immédiat de la boucle de test des candidats.")
                    return@withContext token
                }
            } catch (e: Exception) {
                val msg = e.message ?: ""
                // If it is a blocked or invalid MAC error, propagate immediately and stop trying candidates
                if (msg.contains("bloquée") || msg.contains("bloqué") || msg.contains("blocked") || msg.contains("Wrong MAC") || msg.contains("refusée")) {
                    throw e
                }

                // 4. Limiter le nombre de candidats en cas d'échecs répétés par coupure réseau (statut 0, pas d'erreur HTTP)
                if (e is StalkerNetworkCutException || isNetworkCutException(e)) {
                    consecutiveNetworkCuts++
                    Log.w("STALKER_AUTH", "Coupure réseau (statut 0) détectée sur $candidateUrl. Échecs consécutifs: $consecutiveNetworkCuts/3")
                    if (consecutiveNetworkCuts >= 3) {
                        Log.e("STALKER_AUTH", "3 coupures réseau consécutives détectées. Arrêt immédiat du scan des candidats.")
                        throw Exception("Le portail semble bloquer les connexions répétées, réessayez dans quelques instants")
                    }
                } else {
                    // C'était une vraie réponse HTTP (ex: 404, 400), réinitialisation du compteur de coupures
                    consecutiveNetworkCuts = 0
                }

                if (!msg.contains("timeout", ignoreCase = true) && !msg.contains("TIMEOUT")) {
                    allTimedOut = false
                }
                lastException = e
            }
        }
        
        if (allTimedOut) {
            throw Exception("Portail injoignable après plusieurs tentatives (timeout)")
        } else {
            throw lastException ?: Exception("Portail injoignable après plusieurs tentatives (timeout)")
        }
    }

    suspend fun executeStalkerAuthFlow(mac: String, baseUrl: String, ipAddress: String? = null, priorCookie: String? = null): Pair<String, String> {
        val cleanMac = formatMacAddress(mac).uppercase()
        val deviceFields = generateStalkerDeviceFields(cleanMac)
        val devId = deviceFields["device_id"] ?: ""
        var devId2 = deviceFields["device_id2"] ?: ""
        if (baseUrl.contains("deirnet.ps", ignoreCase = true)) {
            devId2 = ""
        }
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val userAgent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        val xUserAgent = "Model: MAG250; Link: WiFi"

        val isValidIpv4 = { ip: String ->
            val regex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
            regex.matches(ip)
        }
        val customIp = ipAddress?.trim() ?: ""
        val hasCustomIp = customIp.isNotEmpty() && isValidIpv4(customIp)

        val userCardVal = if (hasCustomIp) {
            "mac=$cleanMac; stb_lang=en; timezone=GMT; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial; ip=$customIp"
        } else {
            "mac=$cleanMac; stb_lang=en; timezone=GMT; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
        }

        var normalizedBase = baseUrl.trim()
        if (normalizedBase.endsWith("server/load.php")) {
            normalizedBase = normalizedBase.removeSuffix("server/load.php")
        } else if (normalizedBase.endsWith("portal.php")) {
            normalizedBase = normalizedBase.removeSuffix("portal.php")
        }
        if (!normalizedBase.endsWith("/")) {
            normalizedBase += "/"
        }

        // Strict 10s maximum timeout for handshake calls & disable redirects
        val handshakeClient = getUnsafeOkHttpClientWithoutInterceptor().newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        // 1. Session préalable : exécution QU'UNE SEULE FOIS ou réutilisation du cookie fourni
        val sessionCookie = if (priorCookie != null) {
            Log.d("PortalConnectDebug", "Using prior session cookie without performing duplicate GET request: $priorCookie")
            priorCookie
        } else {
            fetchPriorSessionCookie(cleanMac, normalizedBase, ipAddress)
        }

        // 2. Variantes d'endpoint : portal.php en priorité, puis server/load.php, load.php
        val endpoints = listOf("portal.php", "server/load.php", "load.php")
        var lastException: Exception? = null

        val cookieHeaderVal = if (sessionCookie.isNotEmpty()) {
            "mac=$cleanMac; stb_lang=en; timezone=GMT; $sessionCookie"
        } else {
            "mac=$cleanMac; stb_lang=en; timezone=GMT"
        }

        // 3. Paramètres de handshake avec prehash fixé
        val handshakeActionQueries = listOf(
            "type=stb&action=handshake&token=&prehash=868b80d5fa1f01394479e0948ba422cb58d87267&JsHttpRequest=1-xml",
            "type=stb&action=handshake&token=&prehash=868b80d5fa1f01394479e0948ba422cb58d87267&mac=$cleanMac&JsHttpRequest=1-xml",
            "type=itv&action=handshake&token=&prehash=868b80d5fa1f01394479e0948ba422cb58d87267&mac=$cleanMac&JsHttpRequest=1-xml",
            "type=stb&action=handshake&token=&mac=$cleanMac&JsHttpRequest=1-xml",
            "type=stb&action=handshake&mac=$cleanMac"
        )

        for (endpoint in endpoints) {
            for (actionQuery in handshakeActionQueries) {
                val handshakeUrl = "${normalizedBase}${endpoint}?$actionQuery"
                val startTime = System.currentTimeMillis()

                val handshakeRequestBuilder = Request.Builder()
                    .url(handshakeUrl)
                    .header("User-Agent", userAgent)
                    .header("X-User-Agent", xUserAgent)
                    .header("X-User-Card", userCardVal)
                    .header("Cookie", cookieHeaderVal)
                    .header("Referer", normalizedBase)
                    .header("Accept", "*/*")
                    .header("Accept-Language", "en-US,fr-FR;q=0.9,en;q=0.8")

                if (hasCustomIp) {
                    handshakeRequestBuilder.header("X-Forwarded-For", customIp)
                    handshakeRequestBuilder.header("X-Real-IP", customIp)
                    handshakeRequestBuilder.header("Client-IP", customIp)
                }

                val handshakeRequest = handshakeRequestBuilder.build()

                val attemptNum = ApiService.incrementHandshakeCounter()
                Log.d("StalkerRepository", "Tentative de handshake #$attemptNum sur $handshakeUrl ($endpoint)")

                try {
                    handshakeClient.newCall(handshakeRequest).execute().use { response ->
                        val elapsed = System.currentTimeMillis() - startTime
                        val httpCode = response.code
                        val isRedirect = response.isRedirect || (httpCode in 300..399)
                        val redirectLoc = response.header("Location") ?: ""

                        val statusStr = if (isRedirect) {
                            "$httpCode (Redirect: $redirectLoc)"
                        } else {
                            "$httpCode"
                        }

                        val cookieLog = if (sessionCookie.isNotEmpty()) sessionCookie else "None"
                        Log.d("PortalConnectDebug", "Tested URL: $handshakeUrl | Endpoint: $endpoint | HTTP Status: $statusStr | Response Time: ${elapsed}ms | Session Cookie: $cookieLog")

                        val body = response.body?.string() ?: ""
                        Log.d("STALKER_AUTH", "[HANDSHAKE RESPONSE] HTTP $httpCode ($endpoint), Body: $body")

                        // Check for blocked error messages in the body
                        val lowerBody = body.lowercase()
                        if (lowerBody.contains("mac is blocked") || lowerBody.contains("mac_blocked")) {
                            Log.e("STALKER_AUTH", "[HANDSHAKE ERROR] MAC Bloquée detected.")
                            throw Exception("L'adresse MAC est bloquée par le portail (MAC is blocked).")
                        }
                        if (lowerBody.contains("account is blocked") || lowerBody.contains("account_blocked")) {
                            Log.e("STALKER_AUTH", "[HANDSHAKE ERROR] Compte Bloqué detected.")
                            throw Exception("Le compte associé à cette adresse MAC est bloqué (Account is blocked).")
                        }
                        if (lowerBody.contains("wrong mac") || lowerBody.contains("wrong_mac") || lowerBody.contains("mac_invalid") || lowerBody.contains("invalid mac")) {
                            Log.e("STALKER_AUTH", "[HANDSHAKE ERROR] Wrong MAC detected.")
                            throw Exception("Adresse MAC invalide ou refusée par le portail (Wrong MAC).")
                        }

                        if (!response.isSuccessful && !isRedirect) {
                            lastException = StalkerHttpErrorException(httpCode, "HTTP $httpCode sur $handshakeUrl")
                            return@use
                        }

                        val cleanedBody = cleanStalkerJson(body)
                        val json = try { JSONObject(cleanedBody) } catch(e: Exception) { null }
                        var token = ""
                        if (json != null) {
                            if (json.has("js")) {
                                val jsObj = json.optJSONObject("js")
                                if (jsObj != null) {
                                    token = jsObj.optString("token")
                                } else {
                                    token = json.optString("js")
                                }
                            }
                            if (token.isEmpty() && json.has("token")) {
                                token = json.optString("token")
                            }
                            if (token.isEmpty() && json.has("result")) {
                                val resObj = json.optJSONObject("result")
                                if (resObj != null) {
                                    token = resObj.optString("token")
                                } else {
                                    token = json.optString("result")
                                }
                            }
                            if (token.isEmpty() && json.has("data")) {
                                val dataObj = json.optJSONObject("data")
                                if (dataObj != null) {
                                    token = dataObj.optString("token")
                                }
                            }
                        }

                        if (token.isEmpty()) {
                            val tokenRegex = Regex("""["']?token["']?\s*:\s*["']([^"']+)["']""")
                            val match = tokenRegex.find(body)
                            if (match != null) {
                                token = match.groupValues[1]
                            }
                        }

                        if (token.isNotEmpty()) {
                            Log.d("STALKER_AUTH", "Token obtenu du handshake sur $endpoint : $token. Exécution de get_profile pour validation et activation de session...")
                            val encSn = java.net.URLEncoder.encode(serial, "UTF-8")
                            val encDevId = java.net.URLEncoder.encode(devId, "UTF-8")
                            val encDevId2 = java.net.URLEncoder.encode(devId2, "UTF-8")
                            val encSig = java.net.URLEncoder.encode(sig, "UTF-8")
                            val encToken = java.net.URLEncoder.encode(token, "UTF-8")

                            val profileUrl1 = buildStalkerGetProfileUrl(normalizedBase, endpoint, cleanMac, token)

                            val buildProfileRequest = { targetUrl: String ->
                                val builder = Request.Builder()
                                    .url(targetUrl)
                                    .header("User-Agent", userAgent)
                                    .header("X-User-Agent", xUserAgent)
                                    .header("X-User-Card", userCardVal)
                                    .header("Cookie", cookieHeaderVal)
                                    .header("Authorization", "Bearer $token")
                                    .header("Referer", normalizedBase)
                                    .header("Accept", "*/*")
                                    .header("Accept-Language", "en-US,fr-FR;q=0.9,en;q=0.8")
                                if (hasCustomIp) {
                                    builder.header("X-Forwarded-For", customIp)
                                    builder.header("X-Real-IP", customIp)
                                    builder.header("Client-IP", customIp)
                                }
                                builder.build()
                            }

                            val isValidProfile = { respBody: String, code: Int ->
                                if (code !in 200..299) {
                                    false
                                } else if (respBody.contains("Authorization failed.", ignoreCase = true) || 
                                           respBody.contains("wrong token", ignoreCase = true) || 
                                           respBody.contains("token_invalid", ignoreCase = true)) {
                                    false
                                } else {
                                    val cleaned = cleanStalkerJson(respBody)
                                    val jsonObj = try { JSONObject(cleaned) } catch(e: Exception) { null }
                                    if (jsonObj != null) {
                                        val jsObj = jsonObj.optJSONObject("js")
                                        val resObj = jsonObj.optJSONObject("result")
                                        val targetObj = jsObj ?: resObj ?: jsonObj
                                        targetObj.has("id") || targetObj.has("status") || targetObj.has("login") || 
                                        targetObj.has("name") || targetObj.has("mac") || targetObj.has("stb_type") || 
                                        targetObj.has("parent_password") || targetObj.has("locale") || targetObj.has("account_balance")
                                    } else {
                                        false
                                    }
                                }
                            }

                            var profileSuccess = false
                            try {
                                handshakeClient.newCall(buildProfileRequest(profileUrl1)).execute().use { profResp1 ->
                                    val profBody1 = profResp1.body?.string() ?: ""
                                    Log.d("STALKER_AUTH", "[GET_PROFILE ATTEMPT 1] HTTP ${profResp1.code} ($endpoint), URL: $profileUrl1\nResponse Body: $profBody1")
                                    if (isValidProfile(profBody1, profResp1.code)) {
                                        profileSuccess = true
                                        Log.d("STALKER_AUTH", "[GET_PROFILE SUCCESS] Session activée avec succès lors de la tentative 1 ($endpoint).")
                                    } else {
                                        Log.w("STALKER_AUTH", "[GET_PROFILE FAILED 1] Réponse lors de la tentative 1 ($endpoint).")
                                    }
                                }
                            } catch (e: Exception) {
                                Log.w("STALKER_AUTH", "[GET_PROFILE ERROR 1] Erreur lors de la tentative 1 ($endpoint): ${e.message}")
                            }

                            if (!profileSuccess) {
                                val profileUrl2 = "${normalizedBase}${endpoint}?type=stb&action=get_profile&device_id=$encDevId&device_id2=$encDevId2&signature=$encSig&sn=$encSn&token=$encToken&JsHttpRequest=1-xml"
                                Log.d("STALKER_AUTH", "[GET_PROFILE ATTEMPT 2] Tentative avec paramètres réduits : $profileUrl2")
                                try {
                                    handshakeClient.newCall(buildProfileRequest(profileUrl2)).execute().use { profResp2 ->
                                        val profBody2 = profResp2.body?.string() ?: ""
                                        Log.d("STALKER_AUTH", "[GET_PROFILE ATTEMPT 2] HTTP ${profResp2.code} ($endpoint), URL: $profileUrl2\nResponse Body: $profBody2")
                                        if (isValidProfile(profBody2, profResp2.code)) {
                                            profileSuccess = true
                                            Log.d("STALKER_AUTH", "[GET_PROFILE SUCCESS] Session activée avec succès lors de la tentative 2 ($endpoint).")
                                        } else {
                                            Log.w("STALKER_AUTH", "[GET_PROFILE FAILED 2] Réponse lors de la tentative 2 ($endpoint).")
                                        }
                                    }
                                } catch (e: Exception) {
                                    Log.w("STALKER_AUTH", "[GET_PROFILE ERROR 2] Erreur lors de la tentative 2 ($endpoint): ${e.message}")
                                }
                            }

                            if (!profileSuccess) {
                                val profileUrl3 = "${normalizedBase}${endpoint}?type=stb&action=get_profile&token=$encToken&JsHttpRequest=1-xml"
                                Log.d("STALKER_AUTH", "[GET_PROFILE ATTEMPT 3] Tentative minimale : $profileUrl3")
                                try {
                                    handshakeClient.newCall(buildProfileRequest(profileUrl3)).execute().use { profResp3 ->
                                        val profBody3 = profResp3.body?.string() ?: ""
                                        if (profResp3.isSuccessful && !profBody3.contains("Authorization failed", ignoreCase = true)) {
                                            profileSuccess = true
                                            Log.d("STALKER_AUTH", "[GET_PROFILE SUCCESS] Session activée avec succès lors de la tentative 3 ($endpoint).")
                                        }
                                    }
                                } catch (e: Exception) {
                                    Log.w("STALKER_AUTH", "[GET_PROFILE ERROR 3]: ${e.message}")
                                }
                            }

                            Log.d("StalkerRepository", "Handshake validé ($endpoint). Token: $token. Temporisation de 300ms...")
                            kotlinx.coroutines.delay(300)
                            return Pair(token, endpoint)
                        }
                    }
                } catch (e: Exception) {
                    val elapsed = System.currentTimeMillis() - startTime
                    val isTimeout = e is java.net.SocketTimeoutException || 
                                    e is java.io.InterruptedIOException || 
                                    (e.message?.contains("timeout", ignoreCase = true) == true)

                    val cookieLog = if (sessionCookie.isNotEmpty()) sessionCookie else "None"
                    if (isTimeout) {
                        Log.e("PortalConnectDebug", "Tested URL: $handshakeUrl | Endpoint: $endpoint | HTTP Status: TIMEOUT | Response Time: ${elapsed}ms | Session Cookie: $cookieLog")
                        lastException = StalkerNetworkCutException("Timeout lors de la connexion à $handshakeUrl", e)
                    } else {
                        Log.e("PortalConnectDebug", "Tested URL: $handshakeUrl | Endpoint: $endpoint | Error: ${e.message} | Response Time: ${elapsed}ms | Session Cookie: $cookieLog")
                        val msg = e.message ?: ""
                        if (msg.contains("bloquée") || msg.contains("bloqué") || msg.contains("blocked") || msg.contains("Wrong MAC") || msg.contains("refusée")) {
                            throw e
                        }
                        lastException = StalkerNetworkCutException(e.message ?: "Échec de connexion réseau", e)
                    }
                }
                // Pause entre les requêtes d'endpoints/actions pour éviter le mitraillage
                kotlinx.coroutines.delay(200)
            }
        }

        throw lastException ?: StalkerNetworkCutException("Portail injoignable sur $normalizedBase")
    }

    suspend fun fetchAllStalkerCategories(
        client: OkHttpClient,
        cleanUrl: String,
        token: String,
        mac: String
    ): Pair<List<StalkerCategory>, List<StalkerCategory>> = withContext(Dispatchers.IO) {
        val cachedHs = getCachedHandshakeResult(cleanUrl, mac)
        val cleanUrlNormalized = if (cachedHs != null && cachedHs.resolvedUrl.isNotEmpty()) {
            if (cachedHs.resolvedUrl.endsWith("/")) cachedHs.resolvedUrl else "${cachedHs.resolvedUrl}/"
        } else {
            var norm = cleanUrl.trim().substringBefore("?").substringBefore("#")
            if (!norm.endsWith("/")) "$norm/" else norm
        }

        val endpointPath = cachedHs?.endpointPath ?: "server/load.php"

        suspend fun callGetCategories(type: String, extra: String = ""): List<StalkerCategory> {
            val url = "${cleanUrlNormalized}${endpointPath}?type=$type&action=get_categories$extra&token=$token&JsHttpRequest=1-xml"
            val req = Request.Builder().url(url).apply {
                header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                header("Cookie", "mac=$mac; stb_lang=en; timezone=GMT; token=$token")
                header("Referer", cleanUrlNormalized)
            }.build()
            
            return try {
                client.newCall(req).execute().use { res ->
                    val body = res.body?.string() ?: return@use emptyList()
                    val js = JSONObject(cleanStalkerJson(body)).optJSONObject("js") ?: return@use emptyList()
                    val data = js.optJSONArray("data") ?: js.optJSONArray("categories") ?: JSONArray()
                    val list = mutableListOf<StalkerCategory>()
                    for (i in 0 until data.length()) {
                        val o = data.optJSONObject(i) ?: continue
                        val id = o.optString("id").ifEmpty { o.optString("category_id") }
                        val title = o.optString("title").ifEmpty { o.optString("name") }
                        if (id.isNotEmpty() && title.isNotEmpty()) {
                            list.add(StalkerCategory(id, title, type == "series"))
                        }
                    }
                    list
                }
            } catch (e: Exception) {
                Log.e("STALKER_CATS", "Error calling get_categories for type $type: ${e.message}")
                emptyList()
            }
        }

        // 1. On récupère VOD et SERIES séparément, jamais ensemble
        var movieCats = callGetCategories("vod")
        var seriesCats = callGetCategories("series")
        
        // Fallback pour les portails qui n'ont pas type=series
        if (seriesCats.isEmpty()) {
            seriesCats = callGetCategories("vod", "&movie_type=2")
            // Si on a utilisé movie_type=2, il faut l'enlever des movieCats
            if (seriesCats.isNotEmpty()) {
                val seriesIds = seriesCats.map { it.id }.toSet()
                movieCats = movieCats.filter { it.id !in seriesIds }
            }
        }
        
        Log.d("STALKER_CATS", "Movies Cats: ${movieCats.size}, Series Cats: ${seriesCats.size}")
        return@withContext Pair(movieCats, seriesCats)
    }

    fun getCachedHandshakeResult(portalUrl: String, mac: String): HandshakeResult? {
        val cleanMac = formatMacAddress(mac).uppercase()
        val cleanPortalUrl = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
        val strippedPortalUrl = portalUrl.trimEnd('/')

        // 1. Direct key lookups
        handshakeCache["$portalUrl|$cleanMac"]?.let { if (!it.token.startsWith("mock_token_")) return it }
        handshakeCache["$cleanPortalUrl|$cleanMac"]?.let { if (!it.token.startsWith("mock_token_")) return it }
        handshakeCache["$strippedPortalUrl|$cleanMac"]?.let { if (!it.token.startsWith("mock_token_")) return it }

        // 2. Search by matching MAC and URL containment or overlap
        for ((key, result) in handshakeCache) {
            if (key.endsWith("|$cleanMac") && !result.token.startsWith("mock_token_")) {
                if (key.startsWith(strippedPortalUrl) || strippedPortalUrl.startsWith(result.resolvedUrl.trimEnd('/')) || result.resolvedUrl.startsWith(strippedPortalUrl)) {
                    return result
                }
            }
        }

        // 3. Fallback: Match any valid non-mock token for this MAC
        for ((key, result) in handshakeCache) {
            if (key.endsWith("|$cleanMac") && !result.token.startsWith("mock_token_")) {
                return result
            }
        }
        return null
    }

    fun performHandshake(portalUrl: String, mac: String, forceRefresh: Boolean = false): HandshakeResult {
        val cleanMac = formatMacAddress(mac).uppercase()
        if (forceRefresh) {
            handshakeCache.remove("$portalUrl|$cleanMac")
        }
        val cached = if (forceRefresh) null else getCachedHandshakeResult(portalUrl, cleanMac)
        if (cached != null) {
            Log.d("STALKER_DEBUG", "Using cached handshake result for $portalUrl|$cleanMac: endpoint=${cached.endpointPath}")
            return cached
        }

        try {
            return kotlinx.coroutines.runBlocking {
                authMutex.withLock {
                    if (!forceRefresh) {
                        val cachedAfterLock = getCachedHandshakeResult(portalUrl, cleanMac)
                        if (cachedAfterLock != null) {
                            return@withLock cachedAfterLock
                        }
                    }
                    authenticateStalker(cleanMac, portalUrl)
                    val cachedResult = getCachedHandshakeResult(portalUrl, cleanMac)
                    if (cachedResult != null) {
                        return@withLock cachedResult
                    }
                    val fallbackEndpoint = if (portalUrl.contains("portal.php")) "portal.php" else "server/load.php"
                    return@withLock HandshakeResult("mock_token_" + cleanMac.replace(":", ""), portalUrl, cleanMac, fallbackEndpoint)
                }
            }
        } catch (e: Exception) {
            Log.e("STALKER_DEBUG", "Error during performHandshake robust authentication: ${e.message}")
        }

        val fallbackEndpoint = if (portalUrl.contains("portal.php")) "portal.php" else "server/load.php"
        return HandshakeResult("mock_token_" + cleanMac.replace(":", ""), portalUrl, cleanMac, fallbackEndpoint)
    }

    fun rewriteLocalhost(resolvedUrl: String, portalUrl: String): String {
        try {
            val resolvedUri = android.net.Uri.parse(resolvedUrl)
            val host = resolvedUri.host
            if (host == "localhost" || host == "127.0.0.1") {
                val portalUri = android.net.Uri.parse(portalUrl)
                val portalAuthority = portalUri.authority // e.g. "domain.com:8080"
                val portalScheme = portalUri.scheme ?: "http"
                
                // Reconstruct the URL using portal's scheme and authority
                val builder = resolvedUri.buildUpon()
                    .scheme(portalScheme)
                    .encodedAuthority(portalAuthority)
                return builder.build().toString()
            }
        } catch (e: Exception) {
            Log.e("ApiService", "Error rewriting localhost in URL: $resolvedUrl", e)
        }
        return resolvedUrl
    }

    private fun ensureAbsoluteUrl(resolvedUrl: String, portalUrl: String): String {
        var url = resolvedUrl.trim()
        if (url.isEmpty() || url.equals("null", ignoreCase = true) || url.equals("false", ignoreCase = true) || url.equals("none", ignoreCase = true) || url.startsWith("{") || url.startsWith("[")) {
            return ""
        }
        val prefixes = listOf("ffrt ", "ffrt2 ", "ffrt3 ", "ffrt4 ", "ffmpeg ", "auto ", "standalone ", "shoutcast ", "mp3 ", "m3u8 ", "ts ")
        var changed = true
        while (changed) {
            changed = false
            for (p in prefixes) {
                if (url.startsWith(p, ignoreCase = true)) {
                    url = url.substring(p.length).trim()
                    changed = true
                }
            }
        }
        url = url.removeSurrounding("\"").removeSurrounding("'").trim()
        if (url.isEmpty() || url.equals("null", ignoreCase = true) || url.equals("false", ignoreCase = true)) {
            return ""
        }
        
        if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("rtmp://") && !url.startsWith("rtsp://") && !url.startsWith("mms://")) {
            // It's a relative path!
            try {
                val portalUri = android.net.Uri.parse(portalUrl)
                val scheme = portalUri.scheme ?: "http"
                val authority = portalUri.authority ?: ""
                val base = "$scheme://$authority"
                if (url.startsWith("/")) {
                    url = base + url
                } else {
                    url = "$base/$url"
                }
            } catch (e: Exception) {
                Log.e("ApiService", "Failed to resolve absolute URL for $url: ${e.message}")
            }
        } else {
            // It's an absolute URL, check if we need to rewrite localhost
            url = rewriteLocalhost(url, portalUrl)
        }
        return url
    }

    /**
     * Étape 4 - Parcours Deirnet : create_link pour un fichier (ex: /media/file_156956.mpg)
     */
    fun resolveDeirnetFileStreamUrl(portalUrl: String, mac: String, token: String, fileId: String): String? {
        if (fileId.isEmpty()) return null
        try {
            val formattedMac = formatMacAddress(mac)
            val handshakeResult = performHandshake(portalUrl, formattedMac)
            val activeToken = if (token.isNotEmpty()) token else handshakeResult.token
            val cleanUrl = if (handshakeResult.resolvedUrl.endsWith("/")) handshakeResult.resolvedUrl else "${handshakeResult.resolvedUrl}/"
            val activeEndpoint = handshakeResult.endpointPath
            
            val deviceFields = generateStalkerDeviceFields(formattedMac)
            val devId = deviceFields["device_id"] ?: ""
            var devId2 = deviceFields["device_id2"] ?: ""
            if (cleanUrl.contains("deirnet.ps", ignoreCase = true) || portalUrl.contains("deirnet.ps", ignoreCase = true)) {
                devId2 = ""
            }
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""
            val userCardVal = "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
            
            val encodedCmd = java.net.URLEncoder.encode("/media/file_$fileId.mpg", "UTF-8")
            val linkUrl = "${cleanUrl}${activeEndpoint}?type=vod&action=create_link&cmd=$encodedCmd&series=1&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&token=$activeToken&JsHttpRequest=1-xml"
            Log.d("VodPlaybackDebug", "[ÉTAPE 4] create_link pour /media/file_$fileId.mpg URL=$linkUrl")
            
            val req = Request.Builder().url(linkUrl)
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .header("X-User-Card", userCardVal)
                .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$activeToken; ad=1")
                .header("Referer", cleanUrl)
                .header("Accept", "*/*")
                .header("Authorization", "Bearer $activeToken")
                .build()

            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: ""
                    val cleaned = cleanStalkerJson(bodyStr)
                    val jsonObj = try { org.json.JSONObject(cleaned) } catch (e: Exception) { null }
                    if (jsonObj != null) {
                        val jsObj = jsonObj.optJSONObject("js") ?: jsonObj
                        val streamCmd = jsObj.optString("cmd").ifEmpty { jsObj.optString("url") }.ifEmpty { jsObj.optString("path") }.trim()
                        if (streamCmd.isNotEmpty() && (streamCmd.startsWith("http://") || streamCmd.startsWith("https://"))) {
                            val cleanStreamUrl = streamCmd.substringAfter("ffmpeg ").trim()
                            Log.d("VodPlaybackDebug", "[ÉTAPE 4] Stream CDN résolu avec succès : $cleanStreamUrl")
                            return cleanStreamUrl
                        }
                    }
                } else {
                    Log.w("VodPlaybackDebug", "[ÉTAPE 4] create_link échec HTTP code: ${response.code}")
                }
                Unit
            }
        } catch (e: Exception) {
            Log.e("VodPlaybackDebug", "[ÉTAPE 4] Erreur resolveDeirnetFileStreamUrl: ${e.message}", e)
        }
        return null
    }

    fun resolveStalkerStream(portalUrl: String, mac: String, cmd: String, streamType: String = "Live"): String? {
        val initial = resolveStalkerStreamInternal(portalUrl, mac, cmd, streamType, forceRefresh = false)
        if (!initial.isNullOrBlank()) {
            return initial
        }
        Log.d("ApiService", "Initial resolveStalkerStream returned empty. Retrying with fresh handshake token...")
        return resolveStalkerStreamInternal(portalUrl, mac, cmd, streamType, forceRefresh = true)
    }

    private fun resolveStalkerStreamInternal(portalUrl: String, mac: String, cmd: String, streamType: String, forceRefresh: Boolean): String? {
        // Check if the command (with or without 'ffmpeg ') is already a direct playable external HTTP stream URL
        var cleanCmd = cmd.trim()
        if (cleanCmd.startsWith("ffmpeg ")) {
            cleanCmd = cleanCmd.substringAfter("ffmpeg ").trim()
        }
        if ((cleanCmd.startsWith("http://") || cleanCmd.startsWith("https://")) && !cleanCmd.contains("localhost") && !cleanCmd.contains("127.0.0.1")) {
            Log.d("ApiService", "Stream is already a direct URL: $cleanCmd")
            return cleanCmd
        }

        try {
            val formattedMac = formatMacAddress(mac)
            val handshakeResult = performHandshake(portalUrl, formattedMac, forceRefresh = forceRefresh)
            val token = handshakeResult.token
            val cleanUrl = if (handshakeResult.resolvedUrl.endsWith("/")) handshakeResult.resolvedUrl else "${handshakeResult.resolvedUrl}/"
            val activeEndpoint = handshakeResult.endpointPath
            Log.d("SeasonEpisodeDebug", "resolveStalkerStream: Cached full base URL '$cleanUrl', endpoint '$activeEndpoint' for portal '$portalUrl' (MAC: $formattedMac, forceRefresh: $forceRefresh)")
            
            var realCmd = cmd
            var seriesParam = ""
            var episodeParam = ""
            var seasonParam = ""
            var seasonNumParam = ""
            var seasonIdParam = ""
            var episodeIdParam = ""
            var fileIdParam = ""
            var seriesIdFromUrl = ""
            var vodIdFromUrl = ""
            var isSeries = streamType.equals("Series", ignoreCase = true)
            
            if (cmd.startsWith("stalker://series/") || cmd.startsWith("stalker://episode/")) {
                isSeries = true
                try {
                    val uri = Uri.parse(cmd)
                    realCmd = uri.getQueryParameter("cmd") ?: cmd
                    seriesParam = uri.getQueryParameter("series") ?: uri.getQueryParameter("episode") ?: ""
                    episodeParam = uri.getQueryParameter("episode") ?: ""
                    seasonParam = uri.getQueryParameter("season") ?: ""
                    seasonNumParam = uri.getQueryParameter("season_num") ?: ""
                    seasonIdParam = uri.getQueryParameter("season_id") ?: ""
                    episodeIdParam = uri.getQueryParameter("episode_id") ?: ""
                    fileIdParam = uri.getQueryParameter("file_id") ?: ""
                    seriesIdFromUrl = if (cmd.startsWith("stalker://series/")) {
                        cmd.substringAfter("stalker://series/").substringBefore("?")
                    } else {
                        cmd.substringAfter("stalker://episode/").substringBefore("?")
                    }
                } catch (e: Exception) {
                    Log.e("SeasonEpisodeDebug", "Error parsing stalker series/episode URL: ${e.message}")
                }
            } else if (cmd.startsWith("stalker://vod/") || cmd.startsWith("stalker://movie/")) {
                try {
                    val uri = Uri.parse(cmd)
                    realCmd = uri.getQueryParameter("cmd") ?: cmd
                    fileIdParam = uri.getQueryParameter("file_id") ?: ""
                    vodIdFromUrl = if (cmd.startsWith("stalker://vod/")) {
                        cmd.substringAfter("stalker://vod/").substringBefore("?")
                    } else {
                        cmd.substringAfter("stalker://movie/").substringBefore("?")
                    }
                } catch (e: Exception) {
                    Log.e("SeasonEpisodeDebug", "Error parsing stalker vod/movie URL: ${e.message}")
                }
            }

            // --- FORMAT DETECTION & LOGGING ---
            val rawCmdToDetect = realCmd.ifEmpty { cmd }
            val detectedFormat = detectCmdFormat(rawCmdToDetect)
            val formatStr = when (detectedFormat) {
                StalkerCmdFormat.JSON_XTREAM -> "json_xtream"
                StalkerCmdFormat.STALKER_MEDIA -> "stalker_media"
                StalkerCmdFormat.UNKNOWN -> "inconnu"
            }
            Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Format de cmd détecté: '$formatStr' pour cmd='$cmd' (realCmd='$realCmd', streamType='$streamType')")

            var cleanRealCmd = realCmd.trim()
            if (cleanRealCmd.startsWith("ffmpeg ")) {
                cleanRealCmd = cleanRealCmd.substringAfter("ffmpeg ").trim()
            }
            if ((cleanRealCmd.startsWith("http://") || cleanRealCmd.startsWith("https://")) && !cleanRealCmd.contains("localhost") && !cleanRealCmd.contains("127.0.0.1")) {
                Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] realCmd est déjà une URL directe: $cleanRealCmd")
                return cleanRealCmd
            }

            val executeCreateLinkCall = { targetUrl: String ->
                val deviceFields = generateStalkerDeviceFields(formattedMac)
                val devId = deviceFields["device_id"] ?: ""
                var devId2 = deviceFields["device_id2"] ?: ""
                if (cleanUrl.contains("deirnet.ps", ignoreCase = true) || portalUrl.contains("deirnet.ps", ignoreCase = true)) {
                    devId2 = ""
                }
                val sig = deviceFields["signature"] ?: ""
                val serial = deviceFields["serial_number"] ?: ""

                val request = Request.Builder()
                    .url(targetUrl)
                    .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                    .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                    .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                    .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token")
                    .header("Referer", "${cleanUrl}an_index.html")
                    .header("Authorization", "Bearer $token")
                    .build()

                try {
                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: ""
                            Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] create_link réponse: $body")
                            if (body.isNotEmpty()) {
                                val cleanedBody = cleanStalkerJson(body)
                                val json = try { JSONObject(cleanedBody) } catch (e: Exception) { null }
                                if (json != null) {
                                    fun sanitizeCandidate(str: String): String {
                                        val s = str.trim()
                                        if (s.isEmpty() || s.equals("null", ignoreCase = true) || s.equals("false", ignoreCase = true) || s.equals("none", ignoreCase = true) || s.startsWith("{") || s.startsWith("[")) {
                                            return ""
                                        }
                                        return s
                                    }

                                    var resultUrl = ""
                                    if (json.has("js")) {
                                        val jsObj = json.optJSONObject("js")
                                        resultUrl = sanitizeCandidate(jsObj?.optString("cmd")?.ifEmpty { jsObj.optString("url") } ?: json.optString("js"))
                                    }
                                    if (resultUrl.isEmpty() && json.has("result")) {
                                        val resObj = json.optJSONObject("result")
                                        resultUrl = sanitizeCandidate(resObj?.optString("cmd")?.ifEmpty { resObj.optString("url") } ?: json.optString("result"))
                                    }
                                    if (resultUrl.isEmpty() && json.has("cmd")) {
                                        resultUrl = sanitizeCandidate(json.optString("cmd"))
                                    }
                                    if (resultUrl.isEmpty() && json.has("url")) {
                                        resultUrl = sanitizeCandidate(json.optString("url"))
                                    }
                                    if (resultUrl.isEmpty() && json.has("data")) {
                                        val dataObj = json.optJSONObject("data")
                                        resultUrl = sanitizeCandidate(dataObj?.optString("cmd")?.ifEmpty { dataObj.optString("url") } ?: json.optString("data"))
                                    }
                                    if (resultUrl.isNotEmpty()) {
                                        val absUrl = ensureAbsoluteUrl(resultUrl, cleanUrl)
                                        if (absUrl.isNotBlank()) {
                                            return@use absUrl
                                        }
                                    }
                                }
                            }
                        }
                        null
                    }
                } catch (e: Exception) {
                    Log.e("SeasonEpisodeDebug", "Erreur lors de l'appel create_link ($targetUrl): ${e.message}")
                    null
                }
            }

            val encodedCmd = java.net.URLEncoder.encode(cleanRealCmd, "UTF-8")

            if (isSeries) {
                var videoId = seriesIdFromUrl
                var sId = seasonIdParam
                var epId = episodeIdParam
                var fId = fileIdParam

                if (cmd.startsWith("stalker://") || cmd.contains("?")) {
                    try {
                        val uri = Uri.parse(cmd)
                        if (videoId.isEmpty()) videoId = uri.getQueryParameter("movie_id") ?: uri.getQueryParameter("series_id") ?: uri.getQueryParameter("series") ?: ""
                        if (sId.isEmpty()) sId = uri.getQueryParameter("season_id") ?: uri.getQueryParameter("season") ?: uri.getQueryParameter("season_num") ?: ""
                        if (epId.isEmpty()) epId = uri.getQueryParameter("episode_id") ?: uri.getQueryParameter("episode") ?: ""
                        if (fId.isEmpty()) fId = uri.getQueryParameter("file_id") ?: ""
                    } catch (e: Exception) {
                        Log.e("VodPlaybackDebug", "[ÉPISODE SÉRIE] Erreur de parsing de l'URL d'épisode: ${e.message}")
                    }
                }

                Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] 1. Début résolution épisode: video_id=$videoId, season_id=$sId, episode_id=$epId, file_id=$fId")

                var targetFileId = fId
                if (targetFileId.isEmpty() && videoId.isNotEmpty()) {
                    for (epType in listOf("series", "vod", "tv_series")) {
                        val epUrl = "${cleanUrl}${activeEndpoint}?type=$epType&action=get_ordered_list&movie_id=$videoId&series_id=$videoId&season_id=$sId&season=$sId&episode_id=$epId&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                        Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] 2. Appel get_ordered_list ($epType) pour épisode: $epUrl")
                        val epReq = Request.Builder().url(epUrl)
                            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                            .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                            .header("Referer", cleanUrl)
                            .header("Accept", "*/*")
                            .header("Authorization", "Bearer $token")
                            .build()
                        try {
                            client.newCall(epReq).execute().use { response ->
                                if (response.isSuccessful) {
                                    val bodyStr = response.body?.string() ?: ""
                                    val filesArr = cleanAndExtractStalkerArray(bodyStr)
                                    if (filesArr != null && filesArr.length() > 0) {
                                        for (i in 0 until filesArr.length()) {
                                            val fObj = filesArr.optJSONObject(i) ?: continue
                                            if (fObj.optInt("is_file") == 1 || fObj.optBoolean("is_file") || filesArr.length() == 1) {
                                                targetFileId = fObj.optString("id").trim()
                                                if (targetFileId.isNotEmpty()) break
                                            }
                                        }
                                        if (targetFileId.isEmpty()) {
                                            targetFileId = filesArr.optJSONObject(0)?.optString("id")?.trim() ?: ""
                                        }
                                        Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] Objet fichier trouvé ('is_file':true) avec id=$targetFileId (type=$epType)")
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("VodPlaybackDebug", "[ÉPISODE SÉRIE] Erreur lors de l'appel get_ordered_list: ${e.message}")
                        }
                        if (targetFileId.isNotEmpty()) break
                    }
                }

                if (targetFileId.isNotEmpty()) {
                    Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] 3. Appel resolveDeirnetFileStreamUrl pour file_id=$targetFileId")
                    val resolvedFileUrl = resolveDeirnetFileStreamUrl(portalUrl, mac, token, targetFileId)
                    if (!resolvedFileUrl.isNullOrEmpty()) {
                        Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] 4. Stream d'épisode résolu avec succès via Deirnet file: $resolvedFileUrl")
                        return resolvedFileUrl
                    }
                } else if (cleanRealCmd.isNotEmpty() && cleanRealCmd.all { it.isDigit() }) {
                    Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] 3. Utilisation de realCmd ($cleanRealCmd) comme file_id pour resolveDeirnetFileStreamUrl...")
                    val resolvedFileUrl = resolveDeirnetFileStreamUrl(portalUrl, mac, token, cleanRealCmd)
                    if (!resolvedFileUrl.isNullOrEmpty()) {
                        Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] 4. Stream d'épisode résolu avec succès via realCmd: $resolvedFileUrl")
                        return resolvedFileUrl
                    }
                }

                // Fallback loop over create_link for standard Stalker middleware (xoxpl8k.me, etc.)
                val seriesCmdCandidates = mutableListOf<String>()
                if (cleanRealCmd.isNotEmpty()) seriesCmdCandidates.add(cleanRealCmd)
                if (targetFileId.isNotEmpty() && targetFileId != cleanRealCmd) seriesCmdCandidates.add(targetFileId)
                if (fileIdParam.isNotEmpty() && fileIdParam != targetFileId && fileIdParam != cleanRealCmd) seriesCmdCandidates.add(fileIdParam)

                for (cmdToTry in seriesCmdCandidates) {
                    val encCmd = java.net.URLEncoder.encode(cmdToTry, "UTF-8")
                    for (cType in listOf("series", "vod", "tv_series", "stb")) {
                        // Variant 1: create_link with series parameter
                        val url1 = "${cleanUrl}${activeEndpoint}?type=$cType&action=create_link&cmd=$encCmd&series=${seriesParam.ifEmpty { "1" }}&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&token=$token&JsHttpRequest=1-xml"
                        var resolved = executeCreateLinkCall(url1)
                        if (!resolved.isNullOrEmpty()) {
                            Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] Résolu avec $cType & series param: $resolved")
                            return resolved
                        }

                        // Variant 2: clean create_link
                        val url2 = "${cleanUrl}${activeEndpoint}?type=$cType&action=create_link&cmd=$encCmd&token=$token&JsHttpRequest=1-xml"
                        resolved = executeCreateLinkCall(url2)
                        if (!resolved.isNullOrEmpty()) {
                            Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] Résolu avec $cType clean: $resolved")
                            return resolved
                        }

                        // Variant 3: without JsHttpRequest
                        val url3 = "${cleanUrl}${activeEndpoint}?type=$cType&action=create_link&cmd=$encCmd&token=$token"
                        resolved = executeCreateLinkCall(url3)
                        if (!resolved.isNullOrEmpty()) {
                            Log.d("VodPlaybackDebug", "[ÉPISODE SÉRIE] Résolu avec $cType sans XML: $resolved")
                            return resolved
                        }
                    }
                }

                Log.w("VodPlaybackDebug", "[ÉPISODE SÉRIE] Échec de la résolution de l'épisode pour cmd=$cmd")
                return null
            }

            when (detectedFormat) {
                StalkerCmdFormat.JSON_XTREAM -> {
                    Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stratégie choisie: Tentative unique simple create_link pour format json_xtream.")
                    val primaryType = if (isSeries) "series" else "vod"
                    val singleUrl = "${cleanUrl}${activeEndpoint}?type=$primaryType&action=create_link&cmd=$encodedCmd&token=$token&JsHttpRequest=1-xml"
                    var resolved = executeCreateLinkCall(singleUrl)
                    if (resolved.isNullOrEmpty() && primaryType != "vod") {
                        val fallbackUrl = "${cleanUrl}${activeEndpoint}?type=vod&action=create_link&cmd=$encodedCmd&token=$token&JsHttpRequest=1-xml"
                        resolved = executeCreateLinkCall(fallbackUrl)
                    }
                    if (resolved.isNullOrEmpty()) {
                        val noXmlUrl = "${cleanUrl}${activeEndpoint}?type=$primaryType&action=create_link&cmd=$encodedCmd&token=$token"
                        resolved = executeCreateLinkCall(noXmlUrl)
                    }
                    if (!resolved.isNullOrEmpty()) {
                        Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream résolu avec succès pour json_xtream: $resolved")
                        return resolved
                    }
                }

                StalkerCmdFormat.STALKER_MEDIA -> {
                    Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stratégie choisie: Résolution 3 niveaux deirnet-style pour format stalker_media.")
                    if (isSeries && seriesIdFromUrl.isNotEmpty() && seasonIdParam.isNotEmpty() && episodeIdParam.isNotEmpty()) {
                        var targetFileId = fileIdParam
                        if (targetFileId.isEmpty()) {
                            val epUrl = "${cleanUrl}${activeEndpoint}?type=vod&action=get_ordered_list&movie_id=$seriesIdFromUrl&season_id=$seasonIdParam&episode_id=$episodeIdParam&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                            val epReq = Request.Builder().url(epUrl)
                                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                                .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                                .header("Referer", cleanUrl)
                                .header("Accept", "*/*")
                                .header("Authorization", "Bearer $token")
                                .build()
                            try {
                                client.newCall(epReq).execute().use { response ->
                                    if (response.isSuccessful) {
                                        val bodyStr = response.body?.string() ?: ""
                                        val filesArr = cleanAndExtractStalkerArray(bodyStr)
                                        if (filesArr != null && filesArr.length() > 0) {
                                            for (i in 0 until filesArr.length()) {
                                                val fObj = filesArr.optJSONObject(i) ?: continue
                                                if (fObj.optInt("is_file") == 1 || fObj.optBoolean("is_file") || filesArr.length() == 1) {
                                                    targetFileId = fObj.optString("id").trim()
                                                    if (targetFileId.isNotEmpty()) break
                                                }
                                            }
                                            if (targetFileId.isEmpty()) {
                                                targetFileId = filesArr.optJSONObject(0)?.optString("id")?.trim() ?: ""
                                            }
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                Log.e("SeasonEpisodeDebug", "Erreur get_ordered_list file: ${e.message}")
                            }
                        }
                        if (targetFileId.isNotEmpty()) {
                            val resolvedFileUrl = resolveDeirnetFileStreamUrl(portalUrl, mac, token, targetFileId)
                            if (!resolvedFileUrl.isNullOrEmpty()) {
                                Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream deirnet épisode résolu: $resolvedFileUrl")
                                return resolvedFileUrl
                            }
                        }
                    }

                    val isMovie = !isSeries && (streamType.equals("Movie", ignoreCase = true) || streamType.equals("VOD", ignoreCase = true) || cmd.startsWith("stalker://vod/") || cmd.startsWith("stalker://movie/"))
                    if (isMovie) {
                        var vodId = vodIdFromUrl
                        if (vodId.isEmpty()) {
                            if (cmd.all { it.isDigit() } && cmd.isNotEmpty()) vodId = cmd
                            else if (realCmd.all { it.isDigit() } && realCmd.isNotEmpty()) vodId = realCmd
                        }
                        if (vodId.isNotEmpty()) {
                            var targetFileId = fileIdParam
                            if (targetFileId.isEmpty()) {
                                val movieUrl = "${cleanUrl}${activeEndpoint}?type=vod&action=get_ordered_list&movie_id=$vodId&season_id=0&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                                val movieReq = Request.Builder().url(movieUrl)
                                    .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                                    .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                                    .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                                    .header("Referer", cleanUrl)
                                    .header("Accept", "*/*")
                                    .header("Authorization", "Bearer $token")
                                    .build()
                                try {
                                    client.newCall(movieReq).execute().use { response ->
                                        if (response.isSuccessful) {
                                            val bodyStr = response.body?.string() ?: ""
                                            val filesArr = cleanAndExtractStalkerArray(bodyStr)
                                            if (filesArr != null && filesArr.length() > 0) {
                                                for (i in 0 until filesArr.length()) {
                                                    val fObj = filesArr.optJSONObject(i) ?: continue
                                                    if (fObj.optInt("is_file") == 1 || fObj.optBoolean("is_file") || filesArr.length() == 1) {
                                                        targetFileId = fObj.optString("id").trim()
                                                        if (targetFileId.isNotEmpty()) break
                                                    }
                                                }
                                                if (targetFileId.isEmpty()) {
                                                    targetFileId = filesArr.optJSONObject(0)?.optString("id")?.trim() ?: ""
                                                }
                                            }
                                        }
                                    }
                                } catch (e: Exception) {}
                            }
                            if (targetFileId.isNotEmpty()) {
                                val resolvedFileUrl = resolveDeirnetFileStreamUrl(portalUrl, mac, token, targetFileId)
                                if (!resolvedFileUrl.isNullOrEmpty()) {
                                    Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream deirnet movie résolu: $resolvedFileUrl")
                                    return resolvedFileUrl
                                }
                            }
                        }
                    }

                    val mediaUrl = "${cleanUrl}${activeEndpoint}?type=vod&action=create_link&cmd=$encodedCmd&token=$token&JsHttpRequest=1-xml"
                    var resolved = executeCreateLinkCall(mediaUrl)
                    if (resolved.isNullOrEmpty()) {
                        val mediaUrl2 = "${cleanUrl}${activeEndpoint}?type=series&action=create_link&cmd=$encodedCmd&token=$token&JsHttpRequest=1-xml"
                        resolved = executeCreateLinkCall(mediaUrl2)
                    }
                    if (!resolved.isNullOrEmpty()) {
                        Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream stalker_media résolu: $resolved")
                        return resolved
                    }
                }

                StalkerCmdFormat.UNKNOWN -> {
                    Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stratégie choisie: Résolution create_link pour format standard/live.")
                    val actionType = if (isSeries) "series" else if (streamType.equals("Movie", ignoreCase = true) || streamType.equals("VOD", ignoreCase = true)) "vod" else "itv"

                    val candidateCmds = mutableListOf<String>()
                    if (cleanRealCmd.isNotEmpty()) candidateCmds.add(cleanRealCmd)
                    if (realCmd.isNotEmpty() && realCmd != cleanRealCmd) candidateCmds.add(realCmd)

                    val chIdMatch = Regex("(?:/ch/|ch_)([0-9]+)").find(cleanRealCmd)
                    val extractedChId = chIdMatch?.groupValues?.getOrNull(1) ?: ""
                    if (extractedChId.isNotEmpty()) {
                        candidateCmds.add("auto /ch/${extractedChId}_")
                        candidateCmds.add("/ch/${extractedChId}_")
                        candidateCmds.add(extractedChId)
                    }

                    val endpointsToTry = listOf(
                        activeEndpoint,
                        if (activeEndpoint.contains("portal.php")) "server/load.php" else "portal.php"
                    ).distinct()

                    for (ep in endpointsToTry) {
                        for (c in candidateCmds.distinct()) {
                            val enc = java.net.URLEncoder.encode(c, "UTF-8")
                            val url1 = "${cleanUrl}${ep}?type=$actionType&action=create_link&cmd=$enc&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&token=$token&JsHttpRequest=1-xml"
                            var resolved = executeCreateLinkCall(url1)
                            if (!resolved.isNullOrEmpty()) {
                                Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream résolu avec succès: $resolved")
                                return resolved
                            }

                            val url2 = "${cleanUrl}${ep}?type=$actionType&action=create_link&cmd=$enc&token=$token&JsHttpRequest=1-xml"
                            resolved = executeCreateLinkCall(url2)
                            if (!resolved.isNullOrEmpty()) {
                                Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream résolu avec succès (clean): $resolved")
                                return resolved
                            }

                            val url3 = "${cleanUrl}${ep}?type=$actionType&action=create_link&cmd=$enc&token=$token"
                            resolved = executeCreateLinkCall(url3)
                            if (!resolved.isNullOrEmpty()) {
                                Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Stream résolu avec succès (no-xml): $resolved")
                                return resolved
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("ApiService", "Failed to resolve Stalker stream URL: ${e.message}", e)
        }
        return null
    }

    suspend fun fetchShortEpg(
        portalUrl: String,
        mac: String,
        token: String,
        channelId: String,
        hoursBack: Int = 72
    ): List<EpgProgramItem> = withContext(Dispatchers.IO) {
        val resultList = mutableListOf<EpgProgramItem>()
        val formattedMac = formatMacAddress(mac)
        val cleanUrl = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
        val nowMs = System.currentTimeMillis()
        val windowDays = if (hoursBack <= 0) 3 else (hoursBack / 24).coerceAtLeast(1)
        val cutoffMs = nowMs - (windowDays * 24 * 3600 * 1000L)

        val deviceFields = generateStalkerDeviceFields(formattedMac)
        val devId = deviceFields["device_id"] ?: ""
        val devId2 = deviceFields["device_id2"] ?: ""
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val endpointFileName = getCachedHandshakeResult(portalUrl, formattedMac)?.endpointPath ?: "server/load.php"

        val endpointsToTry = listOf(
            "${endpointFileName}?type=itv&action=get_short_epg&ch_id=${java.net.URLEncoder.encode(channelId, "UTF-8")}&size=100&token=$token&JsHttpRequest=1-xml",
            "${endpointFileName}?type=itv&action=get_short_epg&ch_id=${java.net.URLEncoder.encode(channelId, "UTF-8")}&size=100&token=$token"
        )

        val timeFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        val dateFormat = java.text.SimpleDateFormat("EEE dd/MM HH:mm", java.util.Locale.getDefault())

        for (endpoint in endpointsToTry) {
            val url = "$cleanUrl$endpoint"
            Log.d("CatchupDebug", "fetchShortEpg trying: $url")

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token")
                .header("Authorization", "Bearer $token")
                .build()

            try {
                val response = client.newCall(request).execute()
                val isSuccess = response.isSuccessful
                val body = response.body?.string() ?: ""
                response.close()

                if (isSuccess) {
                    val cleanedBody = cleanStalkerJson(body)
                    if (cleanedBody.isNotEmpty()) {
                        val json = try { JSONObject(cleanedBody) } catch (e: Exception) { null }
                        val jsonArray = if (json != null && json.optJSONArray("js") != null) {
                            json.optJSONArray("js")
                        } else {
                            cleanAndExtractStalkerArray(cleanedBody)
                        }
                        if (jsonArray != null && jsonArray.length() > 0) {
                            for (i in 0 until jsonArray.length()) {
                                val obj = jsonArray.optJSONObject(i) ?: continue
                                val name = obj.optString("name").ifEmpty { obj.optString("title").ifEmpty { obj.optString("o_name") } }
                                if (name.isEmpty()) continue

                                val desc = obj.optString("descr").ifEmpty { obj.optString("description") }
                                val id = obj.optString("id")
                                val realId = obj.optString("real_id").ifEmpty { obj.optString("real_id_epg") }.trim()
                                val maVal = obj.opt("mark_archive") ?: obj.opt("archive") ?: 0
                                val markArchive = when (maVal) {
                                    is Number -> maVal.toInt()
                                    is Boolean -> if (maVal) 1 else 0
                                    is String -> maVal.toIntOrNull() ?: (if (maVal.equals("true", ignoreCase = true) || maVal == "1") 1 else 0)
                                    else -> 0
                                }

                                val startVal = if (obj.has("start_timestamp")) obj.opt("start_timestamp")
                                else if (obj.has("time")) obj.opt("time")
                                else if (obj.has("real_start")) obj.opt("real_start")
                                else null

                                val stopVal = if (obj.has("stop_timestamp")) obj.opt("stop_timestamp")
                                else if (obj.has("time_to")) obj.opt("time_to")
                                else if (obj.has("real_end")) obj.opt("real_end")
                                else null

                                val startMs = parseStalkerTimestamp(startVal)
                                var stopMs = parseStalkerTimestamp(stopVal)

                                if (startMs <= 0L) continue
                                if (stopMs <= 0L) {
                                    stopMs = startMs + (3600 * 1000L)
                                }

                                if (stopMs >= cutoffMs) {
                                    val startFormatted = dateFormat.format(java.util.Date(startMs))
                                    val stopFormatted = timeFormat.format(java.util.Date(stopMs))
                                    resultList.add(
                                        EpgProgramItem(
                                            id = id,
                                            chId = channelId,
                                            name = name,
                                            description = desc,
                                            startTimestamp = startMs,
                                            stopTimestamp = stopMs,
                                            startTimeFormatted = startFormatted,
                                            stopTimeFormatted = stopFormatted,
                                            realId = realId,
                                            markArchive = markArchive
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("CatchupDebug", "Error in fetchShortEpg endpoint $endpoint: ${e.message}")
            }

            if (resultList.isNotEmpty()) {
                Log.d("CatchupDebug", "fetchShortEpg: Success! Loaded ${resultList.size} programs")
                break
            }
        }

        return@withContext resultList.distinctBy { it.startTimestamp }.sortedBy { it.startTimestamp }
    }

    suspend fun fetchEpgForDate(
        portalUrl: String,
        mac: String,
        token: String,
        channelId: String,
        date: String
    ): List<EpgProgramItem> = withContext(Dispatchers.IO) {
        val resultList = mutableListOf<EpgProgramItem>()
        val formattedMac = formatMacAddress(mac)
        val cleanUrl = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"

        val deviceFields = generateStalkerDeviceFields(formattedMac)
        val devId = deviceFields["device_id"] ?: ""
        val devId2 = deviceFields["device_id2"] ?: ""
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val endpointFileName = getCachedHandshakeResult(portalUrl, formattedMac)?.endpointPath ?: "server/load.php"

        val timeFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())

        val suffixesToTry = listOf("&JsHttpRequest=1-xml", "")
        for (suffix in suffixesToTry) {
            resultList.clear()
            var page = 0
            var hasMorePages = true
            while (hasMorePages) {
                val endpoint = "${endpointFileName}?type=epg&action=get_simple_data_table&ch_id=${java.net.URLEncoder.encode(channelId, "UTF-8")}&date=${java.net.URLEncoder.encode(date, "UTF-8")}&p=$page&token=$token$suffix"
                val url = "$cleanUrl$endpoint"
                Log.d("CatchupDebug", "fetchEpgForDate trying page $page: $url")

                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                    .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                    .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                    .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token")
                    .header("Authorization", "Bearer $token")
                    .build()

                var pageItemsAdded = 0
                try {
                    val response = client.newCall(request).execute()
                    val isSuccess = response.isSuccessful
                    val body = response.body?.string() ?: ""
                    response.close()

                    if (isSuccess) {
                        val cleanedBody = cleanStalkerJson(body)
                        if (cleanedBody.isNotEmpty()) {
                            val json = try { JSONObject(cleanedBody) } catch (e: Exception) { null }
                            val jsonArray = if (json != null && json.optJSONArray("js") != null) {
                                json.optJSONArray("js")
                            } else if (json != null && json.optJSONObject("js")?.optJSONArray("data") != null) {
                                json.optJSONObject("js")?.optJSONArray("data")
                            } else if (json != null && json.optJSONArray("data") != null) {
                                json.optJSONArray("data")
                            } else {
                                cleanAndExtractStalkerArray(cleanedBody)
                            }
                            if (jsonArray != null && jsonArray.length() > 0) {
                                for (i in 0 until jsonArray.length()) {
                                    val obj = jsonArray.optJSONObject(i) ?: continue
                                    val name = obj.optString("name").ifEmpty { obj.optString("title").ifEmpty { obj.optString("o_name") } }
                                    if (name.isEmpty()) continue

                                    val desc = obj.optString("descr").ifEmpty { obj.optString("description") }
                                    val id = obj.optString("id")
                                    val realId = obj.optString("real_id").ifEmpty { obj.optString("real_id_epg").ifEmpty { obj.optString("id") } }.trim()
                                    val maVal = obj.opt("mark_archive") ?: obj.opt("archive") ?: 0
                                    val markArchive = when (maVal) {
                                        is Number -> maVal.toInt()
                                        is Boolean -> if (maVal) 1 else 0
                                        is String -> maVal.toIntOrNull() ?: (if (maVal.equals("true", ignoreCase = true) || maVal == "1") 1 else 0)
                                        else -> 0
                                    }

                                    val startVal = if (obj.has("start_timestamp")) obj.opt("start_timestamp")
                                    else if (obj.has("time")) obj.opt("time")
                                    else if (obj.has("real_start")) obj.opt("real_start")
                                    else null

                                    val stopVal = if (obj.has("stop_timestamp")) obj.opt("stop_timestamp")
                                    else if (obj.has("time_to")) obj.opt("time_to")
                                    else if (obj.has("real_end")) obj.opt("real_end")
                                    else null

                                    val startMs = parseStalkerTimestamp(startVal)
                                    var stopMs = parseStalkerTimestamp(stopVal)

                                    if (startMs <= 0L) continue
                                    if (stopMs <= 0L) {
                                        stopMs = startMs + (3600 * 1000L)
                                    }

                                    val startFormatted = timeFormat.format(java.util.Date(startMs))
                                    val stopFormatted = timeFormat.format(java.util.Date(stopMs))
                                    resultList.add(
                                        EpgProgramItem(
                                            id = id,
                                            chId = channelId,
                                            name = name,
                                            description = desc,
                                            startTimestamp = startMs,
                                            stopTimestamp = stopMs,
                                            startTimeFormatted = startFormatted,
                                            stopTimeFormatted = stopFormatted,
                                            realId = realId,
                                            markArchive = markArchive
                                        )
                                    )
                                    pageItemsAdded++
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("CatchupDebug", "Error in fetchEpgForDate page $page: ${e.message}")
                }

                if (pageItemsAdded == 0) {
                    hasMorePages = false
                } else {
                    page++
                    if (page > 30) hasMorePages = false
                }
            }
            if (resultList.isNotEmpty()) {
                Log.d("CatchupDebug", "fetchEpgForDate: Success with suffix '$suffix'! Loaded ${resultList.size} programs for date $date")
                break
            }
        }

        return@withContext resultList.distinctBy { it.startTimestamp }.sortedBy { it.startTimestamp }
    }

    suspend fun fetchXtreamEpg(
        baseUrl: String,
        username: String,
        password: String,
        streamId: String,
        hoursBack: Int = 72
    ): List<EpgProgramItem> = withContext(Dispatchers.IO) {
        val resultList = mutableListOf<EpgProgramItem>()
        val cleanUrl = if (baseUrl.endsWith("/")) baseUrl.dropLast(1) else baseUrl
        val nowMs = System.currentTimeMillis()
        val windowDays = if (hoursBack <= 0) 3 else (hoursBack / 24).coerceAtLeast(1)
        val cutoffMs = nowMs - (windowDays * 24 * 3600 * 1000L)

        val endpoints = listOf(
            "$cleanUrl/player_api.php?username=$username&password=$password&action=get_short_epg&stream_id=$streamId&limit=300",
            "$cleanUrl/player_api.php?username=$username&password=$password&action=get_short_epg&stream_id=$streamId"
        )

        val timeFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        val dateFormat = java.text.SimpleDateFormat("EEE dd/MM HH:mm", java.util.Locale.getDefault())

        for (url in endpoints) {
            Log.d("CatchupDebug", "fetchXtreamEpg trying: $url")
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .build()

            try {
                val response = client.newCall(request).execute()
                val isSuccess = response.isSuccessful
                val body = response.body?.string() ?: ""
                response.close()

                if (isSuccess && body.isNotEmpty()) {
                    val json = try { JSONObject(body) } catch (e: Exception) { null }
                    val jsonArray = if (json != null && json.optJSONArray("epg_listings") != null) {
                        json.optJSONArray("epg_listings")
                    } else if (json != null && json.optJSONArray("data") != null) {
                        json.optJSONArray("data")
                    } else {
                        try { org.json.JSONArray(body) } catch (e: Exception) { null }
                    }

                    if (jsonArray != null && jsonArray.length() > 0) {
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.optJSONObject(i) ?: continue
                            val name = obj.optString("title").ifEmpty { obj.optString("name").ifEmpty { obj.optString("o_name") } }
                            if (name.isEmpty() || name == "No Information" || name == "Pas d'information") continue

                            val desc = obj.optString("description").ifEmpty { obj.optString("descr").ifEmpty { obj.optString("plot") } }
                            val id = obj.optString("id").ifEmpty { obj.optString("epg_id") }
                            
                            val startVal = if (obj.has("start_timestamp")) obj.opt("start_timestamp")
                            else if (obj.has("start")) obj.opt("start")
                            else if (obj.has("time")) obj.opt("time")
                            else null

                            val stopVal = if (obj.has("stop_timestamp")) obj.opt("stop_timestamp")
                            else if (obj.has("end_timestamp")) obj.opt("end_timestamp")
                            else if (obj.has("end")) obj.opt("end")
                            else if (obj.has("time_to")) obj.opt("time_to")
                            else null

                            val startMs = parseStalkerTimestamp(startVal)
                            var stopMs = parseStalkerTimestamp(stopVal)

                            if (startMs <= 0L) continue
                            if (stopMs <= 0L) {
                                stopMs = startMs + (3600 * 1000L)
                            }

                            val maVal = obj.opt("has_archive") ?: obj.opt("archive") ?: obj.opt("mark_archive") ?: 1
                            val markArchive = when (maVal) {
                                is Number -> if (maVal.toInt() > 0) 1 else 0
                                is Boolean -> if (maVal) 1 else 0
                                is String -> if (maVal.equals("true", ignoreCase = true) || maVal == "1" || maVal == "yes") 1 else 0
                                else -> 1
                            }

                            if (stopMs >= cutoffMs) {
                                val startFormatted = dateFormat.format(java.util.Date(startMs))
                                val stopFormatted = timeFormat.format(java.util.Date(stopMs))
                                resultList.add(
                                    EpgProgramItem(
                                        id = id,
                                        chId = streamId,
                                        name = name,
                                        description = desc,
                                        startTimestamp = startMs,
                                        stopTimestamp = stopMs,
                                        startTimeFormatted = startFormatted,
                                        stopTimeFormatted = stopFormatted,
                                        realId = id,
                                        markArchive = markArchive
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("CatchupDebug", "Error in fetchXtreamEpg endpoint $url: ${e.message}")
            }

            if (resultList.isNotEmpty()) {
                Log.d("CatchupDebug", "fetchXtreamEpg: Success! Loaded ${resultList.size} programs")
                break
            }
        }

        return@withContext resultList.distinctBy { it.startTimestamp }.sortedBy { it.startTimestamp }
    }

    private fun parseStalkerTimestamp(value: Any?): Long {
        if (value == null) return 0L
        return when (value) {
            is Number -> {
                val v = value.toLong()
                if (v < 100000000000L) v * 1000L else v
            }
            is String -> {
                val str = value.trim()
                val num = str.toLongOrNull()
                if (num != null) {
                    if (num < 100000000000L) num * 1000L else num
                } else {
                    try {
                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.FRANCE)
                        sdf.timeZone = java.util.TimeZone.getTimeZone("Europe/Paris")
                        sdf.parse(str)?.time ?: 0L
                    } catch (e: Exception) {
                        0L
                    }
                }
            }
            else -> 0L
        }
    }

    suspend fun resolveCatchupStream(
        portalUrl: String,
        mac: String,
        cmd: String,
        programStartTimestamp: Long,
        programStopTimestamp: Long = 0L,
        realId: String = ""
    ): String? {
        Log.d("CatchupDebug", "resolveCatchupStream: cmd=$cmd, startMs=$programStartTimestamp, stopMs=$programStopTimestamp, realId=$realId")
        try {
            val formattedMac = formatMacAddress(mac)
            val handshakeResult = performHandshake(portalUrl, formattedMac)
            val token = handshakeResult.token
            val cleanUrl = if (handshakeResult.resolvedUrl.endsWith("/")) handshakeResult.resolvedUrl else "${handshakeResult.resolvedUrl}/"
            val activeEndpoint = handshakeResult.endpointPath
            Log.d("PlaybackDebug", "resolveCatchupStream: Cached full base URL '$cleanUrl', endpoint '$activeEndpoint' for portal '$portalUrl' (MAC: $formattedMac)")
            Log.d("StalkerRepository", "resolveCatchupStream: Cached full base URL '$cleanUrl', endpoint '$activeEndpoint' for portal '$portalUrl' (MAC: $formattedMac)")
            Log.d("CatchupDebug", "resolveCatchupStream: Cached full base URL '$cleanUrl', endpoint '$activeEndpoint' for portal '$portalUrl' (MAC: $formattedMac)")

            val shortClient = client.newBuilder()
                .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            val utcSec = if (programStartTimestamp > 100000000000L) programStartTimestamp / 1000L else programStartTimestamp
            val stopSec = if (programStopTimestamp > 100000000000L) programStopTimestamp / 1000L else programStopTimestamp
            val lutcSec = if (stopSec > utcSec) stopSec else (System.currentTimeMillis() / 1000L)
            val durMin = if (stopSec > utcSec && utcSec > 0L) {
                ((stopSec - utcSec) / 60L).toInt().coerceAtLeast(1)
            } else {
                60
            }
            val nowSecs = System.currentTimeMillis() / 1000L
            val timeshiftSec = if (utcSec > 0L) (nowSecs - utcSec).coerceAtLeast(60L) else 3600L

            val cleanCmd = cmd.trim().removePrefix("ffrt ").removePrefix("ffmpeg ").removePrefix("auto ").removePrefix("standalone ").trim()
            val cleanChId = cleanCmd.substringAfterLast("/").substringBefore(".").replace(Regex("[^0-9]"), "")
            val cmdsToTry = mutableSetOf(cleanCmd)
            if (cleanChId.isNotEmpty()) {
                cmdsToTry.add("auto /ch/${cleanChId}_")
                cmdsToTry.add("/ch/${cleanChId}_")
                cmdsToTry.add("ch_${cleanChId}")
            }
            if (cmd.trim() != cleanCmd) {
                cmdsToTry.add(cmd.trim())
            }

            val queryParamsToTry = mutableListOf<String>()

            if (realId.isNotEmpty()) {
                val encodedRealId = java.net.URLEncoder.encode(realId, "UTF-8")
                queryParamsToTry.add("type=itv&action=create_link&cmd=$encodedRealId&forced_storage=0&disable_ad=0&duration=$durMin&token=$token&JsHttpRequest=1-xml")
                queryParamsToTry.add("type=itv&action=create_link&cmd=$encodedRealId&duration=$durMin&token=$token")
                for (c in cmdsToTry) {
                    val encCmd = java.net.URLEncoder.encode(c, "UTF-8")
                    queryParamsToTry.add("type=itv&action=create_link&cmd=$encCmd&real_id=$encodedRealId&utc=$utcSec&lutc=$lutcSec&duration=$durMin&token=$token&JsHttpRequest=1-xml")
                    queryParamsToTry.add("type=itv&action=create_link&cmd=$encCmd&real_id=$encodedRealId&utc=$utcSec&lutc=$lutcSec&duration=$durMin&token=$token")
                }
            }

            for (c in cmdsToTry) {
                val encCmd = java.net.URLEncoder.encode(c, "UTF-8")
                val encCmdWithArchive = java.net.URLEncoder.encode("$c archive=$utcSec", "UTF-8")
                val encCmdWithAmpArchive = java.net.URLEncoder.encode("$c&archive=$utcSec", "UTF-8")
                queryParamsToTry.addAll(listOf(
                    "type=itv&action=create_link&cmd=$encCmd&timeshift=$timeshiftSec&token=$token&JsHttpRequest=1-xml",
                    "type=itv&action=create_link&cmd=$encCmd&timeshift=$timeshiftSec&token=$token",
                    "type=itv&action=create_link&cmd=$encCmd&utc=$utcSec&lutc=$lutcSec&duration=$durMin&token=$token&JsHttpRequest=1-xml",
                    "type=itv&action=create_link&cmd=$encCmd&utc=$utcSec&lutc=$lutcSec&duration=$durMin&token=$token",
                    "type=itv&action=create_link&cmd=$encCmd&utc=$utcSec&lutc=$lutcSec&token=$token&JsHttpRequest=1-xml",
                    "type=itv&action=create_link&cmd=$encCmd&utc=$utcSec&lutc=$lutcSec&token=$token",
                    "type=itv&action=create_link&cmd=$encCmd&archive=$utcSec&duration=$durMin&token=$token&JsHttpRequest=1-xml",
                    "type=itv&action=create_link&cmd=$encCmd&archive=$utcSec&duration=$durMin&token=$token",
                    "type=itv&action=create_link&cmd=$encCmdWithArchive&duration=$durMin&token=$token&JsHttpRequest=1-xml",
                    "type=itv&action=create_link&cmd=$encCmdWithArchive&duration=$durMin&token=$token",
                    "type=itv&action=create_link&cmd=$encCmdWithAmpArchive&duration=$durMin&token=$token&JsHttpRequest=1-xml",
                    "type=itv&action=create_link&cmd=$encCmdWithAmpArchive&duration=$durMin&token=$token"
                ))
            }

            val deviceFields = generateStalkerDeviceFields(formattedMac)
            val devId = deviceFields["device_id"] ?: ""
            val devId2 = deviceFields["device_id2"] ?: ""
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""

            val endpointsToTry = listOf(activeEndpoint, if (activeEndpoint == "portal.php") "server/load.php" else "portal.php").distinct()

            for (qp in queryParamsToTry) {
                for (ep in endpointsToTry) {
                    val createLinkUrl = "${cleanUrl}${ep}?$qp"
                    Log.d("PlaybackDebug", "Catchup create_link URL: $createLinkUrl")
                    Log.d("StalkerRepository", "Catchup create_link URL: $createLinkUrl")
                    Log.d("CatchupDebug", "EXECUTE create_link CATCHUP URL: $createLinkUrl")

                    val request = Request.Builder()
                        .url(createLinkUrl)
                        .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                        .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                        .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                        .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token")
                        .header("Referer", "${cleanUrl}an_index.html")
                        .header("Authorization", "Bearer $token")
                        .build()

                    try {
                        val response = kotlinx.coroutines.withTimeoutOrNull(10000L) {
                            shortClient.newCall(request).execute()
                        }
                        if (response == null) {
                            Log.e("CatchupDebug", "Timeout 10s dépassé pour $createLinkUrl")
                            continue
                        }
                        val isSuccess = response.isSuccessful
                        val respCode = response.code
                        val body = response.body?.string() ?: ""
                        response.close()

                        val shortBody = if (body.length > 200) body.substring(0, 200) + "..." else body
                        Log.d("CatchupDebug", "Réponse Catchup (HTTP $respCode) pour $createLinkUrl : $shortBody")

                        if (respCode == 509 || respCode == 429) {
                            Log.e("CatchupDebug", "Limite de connexion détectée (HTTP $respCode) ! Arrêt immédiat.")
                            throw CatchupStreamException("Limite de connexion atteinte : fermez le lecteur en direct avant d'utiliser le catch-up, ou votre abonnement ne permet qu'une seule connexion simultanée")
                        }

                        if (isSuccess) {
                            if (body.isNotEmpty()) {
                                val cleanedBody = cleanStalkerJson(body)
                                val json = try { JSONObject(cleanedBody) } catch (e: Exception) { null }
                                if (json != null) {
                                    var resultUrl = ""
                                    if (json.has("js")) {
                                        val jsObj = json.optJSONObject("js")
                                        if (jsObj != null) {
                                            resultUrl = jsObj.optString("cmd").ifEmpty { jsObj.optString("url") }
                                        } else {
                                            resultUrl = json.optString("js")
                                        }
                                    }
                                    if (resultUrl.isEmpty() && json.has("result")) {
                                        val resObj = json.optJSONObject("result")
                                        if (resObj != null) {
                                            resultUrl = resObj.optString("cmd").ifEmpty { resObj.optString("url") }
                                        } else {
                                            resultUrl = json.optString("result")
                                        }
                                    }
                                    if (resultUrl.isEmpty() && json.has("cmd")) {
                                        resultUrl = json.optString("cmd")
                                    }
                                    if (resultUrl.isEmpty() && json.has("url")) {
                                        resultUrl = json.optString("url")
                                    }

                                    if (resultUrl.isNotEmpty() && !resultUrl.equals("null", ignoreCase = true)) {
                                        var finalUrl = ensureAbsoluteUrl(resultUrl, cleanUrl)
                                        if (finalUrl.contains("duration=", ignoreCase = true)) {
                                            finalUrl = finalUrl.replace(Regex("([?&])duration=[0-9]+"), "$1duration=$durMin")
                                        } else if (finalUrl.contains("timeshift", ignoreCase = true) || finalUrl.contains("archive", ignoreCase = true)) {
                                            val separator = if (finalUrl.contains("?")) "&" else "?"
                                            finalUrl = "$finalUrl${separator}duration=$durMin"
                                        }
                                        Log.d("CatchupDebug", "URL Catch-up résolue avec succès (durée ajustée: ${durMin}m): $finalUrl")
                                        return finalUrl
                                    }
                                }
                            }
                        } else {
                            Log.e("CatchupDebug", "Échec HTTP create_link ($qp): code $respCode")
                        }
                    } catch (e: CatchupStreamException) {
                        throw e
                    } catch (e: Exception) {
                        Log.e("CatchupDebug", "Erreur lors de la tentative $qp: ${e.message}")
                    }
                }
            }
            Log.w("CatchupDebug", "Toutes les tentatives de résolution catch-up ont échoué sans renvoyer d'URL valide.")
            return null
        } catch (e: CatchupStreamException) {
            throw e
        } catch (e: Exception) {
            Log.e("CatchupDebug", "Erreur globale resolveCatchupStream: ${e.message}", e)
        }
        return null
    }
}
